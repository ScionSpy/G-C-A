const discord = require("discord.js");
const gca = require('./src/gca.js');
const Commands = require('./src/discord/Handlers/Commands.js');
const Events = require('./src/discord/Handlers/Events.js');





const bot = new discord.Client({
    presence: {
        status: 'idle',
        activity: {
            type: "LISTENING",
            name: `WoWs.`,
        }
    },
    disableMentions: "everyone"
});

bot.config = require('./config.json');
bot.login(bot.config.token);
delete bot.config.token;

bot.commands = new Commands();
bot.events = new Events(bot);


// find unhandled promise rejections
process.on("unhandledRejection", (err) => console.error(`Unhandled exception`, err));
bot.on("info", (data) => {
    console.log(data);
});

bot.on("ready", async () => {
    console.log(`\n        Logged in as: ${bot.user.tag}`);

    await bot.guilds.cache.get('1126377465741324429').members.fetch();

    let GCA = await gca.Init({
        prefix: '/',
        bot: bot
    });
});
