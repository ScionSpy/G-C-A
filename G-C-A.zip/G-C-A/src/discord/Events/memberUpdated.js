const Web = require('../../Web/index');
const Hooks = require('../../Web/Hooks');
const Hook = new Hooks();
const DB = require('../../Database/index');
const _Consts = require('../../Constants');

module.exports = async function (oldMember, newMember, FORCE = false){
    if((oldMember.displayName != newMember.displayName) || FORCE){
        await oldMember.client.GCA.Constants.logger({ file: 'nicknames', text: `force:${FORCE} || ${oldMember.displayName} -> ${newMember.displayName}` });
        return nicknameUpdated(oldMember, newMember);
    };
};


lookUpName = async function(name){
    name = await name
        //.replace(/\[.*?\] /, "") //Remove "Clan Tags" [MARU], [G-C-A], [SWLF], [RSR] ETC.
        //.replace(/\(.*?\) /, "") //Remove "Ranks" (M), (R), (XO), ETC.
        .replace(/ /g,'_')
        .replace(/\[/g,'')
        .replace(/\]/g,'')
        .replace(/\./g,'')
        .replace(/\'/g,'')
        .replace(/-/g, '')

    let results = await Web.search(name, true);
    if(!results[name]){
        return false;
    }else{
        let res = results[name];
        data = {
            id: res.account_id,
            name: res.account_name,
        };
        if(res.clan){
            data.tag = res.clan.tag;
            data.clan = res.clan.name;
            data.clan_id = res.clan.clan_id;
            data.rank = res.role;
        };

        return data;
    };
};

RequestValidation = async function(player, Member){
    //Admin Lobby post
    let msg = `\<@&1126377465741324437>, Please verifiy **${player.name.replace(/_/g, '\\_')}**'s authenticity in-game.\nThey're claiming the name of a ${Member.client.GCA.Constants.clans_roles[player.rank]}.\n> Once verified, please execute the following:`;

    Member.client.channels.cache.get('1126377466961874964').send(msg);
    Member.client.channels.cache.get('1126377466961874964').send(`\`..verify ${player.name} ${Member.user.id} x\``);
    if (player.name == "ShadowSpyy") Member.client.channels.cache.get('1126377466961874964').send(`\`..verify ${player.name} 213250789823610880 x\``);

    // Lobby notice
    msg = `${Member} (**${player.name}**), as you're a member of [**${player.tag}**] with a rank of **${Member.client.GCA.Constants.clans_roles[player.rank]}**, for your clans security, our administration team will need to verify you manually.\n  This should only take a few moments, after which I will provide you with your tag, rank and appropriate roles!\nThank you for your patience!`;

    Member.client.channels.cache.get('1126377466148180051').send(msg);
};

Claimed = function(name, Member){
    let msg = `**${Member.username}** ${name} has already been claimed!\n  If you believe this is inccorect please contact an Administrator.`;

    Member.client.channels.cache.get('1126377466148180051').send(msg);
};


checkPreVerifiedUsers = async function(name, discoID){
    let VerifiedList = await DB._Get("Verified");
    let Claimed = false

    for(k in VerifiedList){
        let User = VerifiedList[k];
        if(User.name == name){
            Claimed = true;
            break;
        };
    };

    return Claimed;
};


ValidatedCreds = {
    //discordIDs: Timestamps
};

updateClans = async function(clanID, clanName){
    let Clan = await DB._Get("Clans", {clan_id:clanID});

    if(!Clan){
        Clan = await Web.searchClans(clanName);
        //status -1=neutral, 0=hositle 1=allied
        await DB._Edit("Clans", {clan_id:clanID}, {clan_id:Clan.clan_id, name:Clan.name, tag:Clan.tag, created_at:Clan.created_at, status:-1});

        if (_Consts.Allies[Clan.Tag]) {
            let _clan = _Consts.Allies[Clan.Tag];
            await DB._Edit("Clans", { clan_id: clanID }, { ch:_clan.ch, role:_clan.role, status:_clan.status});
        };
    };
};


Update = async function(player, Member, reason, forceVerified){
    let Consts = Member.client.GCA.Constants;
    if(player.clan_id) await updateClans(player.clan_id, player.clan);


    if(!forceVerified){
        if (await checkPreVerifiedUsers(player.name, Member.user.id)){
            let ch = Member.client.channels.cache.get('1126377466148180051');
            let msg = `> That WoWs gamertag (${player.name}) has already been claimed!\n  If you believe either of these to be invalid, please contact an administrator!!`;

            await ch.send(msg);
            Member.setNickname('❌ ' + player.name, 'The name provided has already been claimed!')
            return
        };

        // IF the user is more than a basic member, they require "Verification" in-game.
        if (Consts.Ranks[player.rank] > 2) {
            await Member.setNickname('❗❓ ' + player.name, 'Member Requires validation.');
            return RequestValidation(player, Member);
        };
    };


    let NICK = Consts.Features.nicknames;
    if(player.clan && player.tag == "G-C-A") NICK = '{RANK} {NAME}'

    NICK = NICK.replace('[{TAG}]', player.tag ? `[${player.tag}]` : "");
    NICK = NICK.replace('{RANK}', player.rank ? Consts.Ranks_Short[player.rank] : "");
    NICK = NICK.replace('{NAME}', player.name);

    let Status = {
        nick:false
    };

    ValidatedCreds[Member.user.id] = Date.now();
    await DB._Edit("Verified", { id: player.id }, { id: player.id, discord_id: Member.user.id, name: player.name });

    try{
        Status.nick = await Member.setNickname(NICK, reason);
        if (!await Member.roles.cache.get('1137246581205258240')) Status.roles = await Member.roles.add('1137246581205258240', 'This is a verified member!');
    } catch(err){
        console.error(err);
        //Hook.console(`\`\`\`xl\n${err.stack}\`\`\``)
    };

    if(player.clan_id) await Allies(player, Member);

    return Status;
};


nicknameUpdated = async function( OldMember, NewMember ){
    if((Date.now() - ValidatedCreds[NewMember.user.id]) < 1500) return; //Bot just modified their username.
    if (NewMember.displayName.startsWith('❗') || NewMember.displayName.startsWith('❌')) return; //This was the bot updating their username.
    if (await NewMember.roles.cache.get('1192993068429873323')) return; //Member is current Nickname exempted.
    if (NewMember.displayName.startsWith('[')){
        if (ValidatedCreds[NewMember.user.id] && ValidatedCreds[NewMember.user.id] > (Date.now() - (1000*5))) return;
        else{
            let tag = NewMember.displayName.split(" ");
            //Clan and name are same, this was a rank change!!!
            if(OldMember.displayName.startsWith(tag[0]) && OldMember.displayName.endsWith(tag[2])) return;

            let verified = await DB.isVerified(NewMember.user.id, true);
            if (verified) {
                let player = await lookUpName(verified.name);
                let reason = 'Verified Member attempting to change their Nickanme!!';
                return await Update(player, NewMember, reason, verified);
            }else{
                return NewMember.setNickname('❗ ' + NewMember.displayName, 'The name provided is not a WoWs player name!')
            };
        };
    };



    // Check the Database and see if this user was already verified.
    let verified = await DB.isVerified(NewMember.user.id, true);
    let player;
    let reason;
    //They were verified, reset their nick...
    if (verified) {
        player = await lookUpName(verified.name);

        reason = 'Verified Member attempting to change their Nickanme!!';

    } else {
        player = await lookUpName(NewMember.displayName);
        if (!player.name){
            reason = `The name provided is not a WoWs player name!`;

            await NewMember.setNickname(`❗ `+NewMember.displayName, reason);
            return //return NewMember.guild.channels.cache.get('1126377466148180051').send(`The name you have provided is not listed on the WoWs NA Server.\n  As a result, i have prefixed your name with a \`❗\` to show your unverified status.`);
        } else reason = `Member Verifying their wowsName`;
    };

    return await Update(player, NewMember, reason, verified);
};


Allies = async function(player, Member){
    if (player.tag == "G-C-A") return Member.roles.add('1126377465741324435', 'Member Verifieid their account.').then(async () =>{

        let hasBeenWelcomed = DB._Get("Members", {discord_id:Member.user.id}, {hasBeenWelcomed:1});
        if(hasBeenWelcomed) return;
        else await DB._Edit("Members", {discord_id:Member.user.id}, {hasBeenWelcomed: true});

        let welcome = `> Please Welcome ${Member} to the Clan Discord!!`; //GCA Member Welcome

        await Member.guild.channels.cache.get('1126377466399826033').send(welcome);
        Member.guild.channels.cache.get('1126377466148180051').send(`**${player.name}**, I've granted you access to the Member Channels!\n> Go say hey in <#1126377466399826033>!`);
    });

    let Clan = await Member.client.GCA.DB._Get("Clans", {name:player.clan});
    Clan = Clan[0];

    if(Clan.status === -1) return;

    await Member.roles.add(Clan.role, `Added the ${Clan.tag} role to the member!`)
    .then(async () => {
        let welcome = `> Please Welcome ${Member} to the **[${player.tag}] ${player.clan}** Alliance Channel!`;

        await Member.guild.channels.cache.get(Clan.ch).send(welcome);
        Member.guild.channels.cache.get('1126377466148180051').send(`**${player.name}**, I've granted you access to the **[${player.tag}]** channel.`);
    })
    .catch(err => { console.error(err, Member, player) });


    // ==== ==== ==== ==== \\
    // ==== ==== ==== ==== \\
    // ==== ==== ==== ==== \\


    // Uncomment the below, and remove the above line when we need "More" allies.
    // Alternatively, add a DB entry to the clan "role" with a role ID, make sure the clan entry also has "ch" key for the below function!!


    // Enable the below ONLY AFTER
    // // Other clans are updated automatically.
    // // Users are removed from Channel Overide (Access) when they leave their allied clan!

    // Update "RSR" role to "Alliance Member"
    // // Remove "Allaince Member" role from "RSR Ch" [View Perms = false]


    // ==== ==== ==== ==== \\
    // ==== ==== ==== ==== \\
    // ==== ==== ==== ==== \\

    //if (Clan.status == 1) await Member.roles.add('1126377465741324433', 'Verified Alliance Member!');

    /*if(Clan.ch){
        let ch = await Member.guild.channels.cache.get(Clan.ch);

        if(!ch) return;

        ch.updateOverwrite(Member, {
            VIEW_CHANNEL: true
        })
        .then(async (ch) => {
            let welcome = `> Please Welcome ${Member} to the **[${player.tag}] ${player.clan}** Alliance Channel!`;
            await ch.send(welcome);
            Member.guild.channels.cache.get('1126377466148180051').send(`**${player.name}**, I've granted you access to the **[${player.tag}]** channel.`);
        })
        .catch(err => {console.error(err)});
    };*/
};
