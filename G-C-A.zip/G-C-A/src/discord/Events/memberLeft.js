const roleIDs = require("../../Constants").Role_IDs_byName;
module.exports = async function (guildMember) {
    let lobby = guildMember.guild.channels.cache.get('1126377466148180051');
    let roles = guildMember.roles.cache;

    //Check our Database for rank, etc.

    let msg;

    if(roles.has(roleIDs['verified'])){
        msg = `Verified - `;
    }else msg = `Unverified - `;;

    //is NOT a member, or friend
    if(!roles.has(roleIDs['private']) && !roles.has(roleIDs['__clan_friends'])){
        //They're a merc!
        if(roles.has(roleIDs['__mercenary'])){
            msg = msg+`Merc`;
            
            //Not a merc....
        }else msg = msg+`Player`;

        //IS a member/friend
    }else{
        //is a member
        if(roles.has(roleIDs['private'])){
            msg=msg+`GCA Member`;

            //ToDO: GET RANK

            //is a friend
        }else{
            if(roles.has(roleIDs['__clan_friends'])) msg=msg+`Clan Friend`;
        };
    };

    if(!msg){
        msg = '';
        guildMember.guild.channels.cache.get('1137246476188274750').send(`Error identifying role.\n\`NOT private || __clan_friend\`
        n\`NOT battler || player\`\n{CHECK DB}`);
    };

    if (guildMember.emit) return guildMember.guild.channels.cache.get('1137246476188274750').send(`${guildMember} (${guildMember.displayName}) (\`${msg}\`) has left the server.`);
    lobby.send(`${guildMember} (${guildMember.displayName}) (\`${msg}\`) has left the server.`);
};
