

module.exports = async function(guildMember){
    let lobby = guildMember.guild.channels.cache.get('1126377466148180051');
    let msg;

    msg = `Welcome to the **G-C-A** Discord Server ${guildMember}!`;
    msg = `\n\n If you're a G-C-A Member, or Alliance member, please go read our <#1126377466148180048>!`;
    msg = `\n\n If you're a Merc, please wait while staff assign you the appropriate roles momentarily!!`;


    //lobby.send(msg);

    lobby.send(`Welcome to the **G-C-A** Discord Server ${guildMember}!\n\n Please update your server nickname to match your World of Warships nickname!\n   `/*I will then give you the appropriate roles.\n  `*/+`The Staff will then grant you your appropriate roles on confirmation.\n    Additionally, if you're a Merc, please wait to be assigned the appropriate role.`);
};
