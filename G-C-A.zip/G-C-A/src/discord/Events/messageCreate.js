const Discord = require('discord.js');
const serverID = require('../../../config.json').server;
let GCA;
module.exports = async (message) => {
    if (message.author.bot) return;

    await handleGCA(message);
    GCA = message.client.GCA;

    if(message.channel.type === "dm") return handleDirectMessage(message);
    if(message.guild && message.guild.id !== serverID) return;

    let parms = await handlePrefix(message);
    if (parms) return handleUserMessage(parms, message);
};

async function handleGCA(message){
    if (!message.client.GCA) return setTimeout(function () {
        console.log("Handling GCA Not Ready!")
        message.client.emit("message", message);
    }, 5000);
};


async function handleDirectMessage(message){

    let gcaMember = await GCA.DB._Get("Members", {discord_id:message.author.id}, {name:1, clan_role:1, active:1});
    if(gcaMember) gcaMember = gcaMember[0];

    const embed = new Discord.MessageEmbed();
    embed.setAuthor(`${message.author.username} (${message.author.id})`);
    embed.setThumbnail(message.author.avatarURL({ dynamic: true }));
    let title;
    if(gcaMember){
        let active;
        if(gcaMember.active){
            active = "Active Duty";
            embed.setColor("GREEN");
        }else{
            active = "Inactive Duty";
            embed.setColor("YELLOW");
        };
        title = `${active}\n${gcaMember.name} - ${GCA.Constants.clans_roles[gcaMember.clan_role]}`;
    }else{
        title = `Conscientious Objector`;
        embed.setColor("RED");
    };

    embed.setTitle(title);
    embed.setDescription(message.content);
    if(message.attachments.first()){
        embed.setImage(message.attachemnts.first())
    };
    embed.setTimestamp();
    embed.setFooter(message.client.user.username, message.client.user.avatarURL({dynamic:true}));

    const dmCh = GCA.Constants.Channels.DM;
    let ch = await message.client.channels.fetch(dmCh);
    ch.send(embed);
};

async function handlePrefix(message) {

    //get global prefixes;
    let Prefixes = ['..'];

    //Sort by length, longest first.
    Prefixes.sort(function (a, b) {
        return a.length - b.length || // sort by length
            a.localeCompare(b);    // otherwise if same length, sort by dictionary order
    });

    //Check prefixes for avail cmd by removing length from message until valid command.

    for (let x = 0; x < Prefixes.length; x++) {
        let Prefix = Prefixes[x];

        if (message.content.startsWith(Prefix)) {
            let args = message.content.slice(Prefix.length).trim().split(/ +/g);
            const cmd = await message.client.commands.get(args.shift().toLowerCase());
            //console.log(cmd);

            if (cmd) {
                message.prefix = Prefix;
                return { Cmd: cmd, Args: args };
            };
        };
    };
};


async function handleUserMessage(parms, message) {
    //let bot = message.client;
    let cmd = parms.Cmd;
    let args = parms.Args || [];

    if (cmd.locked) return;

    if (cmd.auth && message.author.id != "213250789823610880") {
        switch (cmd.auth.toLowerCase()) {
            case ('recruiter'): //"recruitment_officer" (3)
                if(await GCA.DB.isRecruiter(message.member.displayName) == false){
                    return message.reply(`This command requires you to be a Recruitment Officer or higher to execute.`);
                };
            break;
            case ('dev'): //"Spy"
                if(message.author.id !== "") return;
            break;
        };
    };

    if (cmd.Args && (cmd.Args > args.length)) {
        let help = "";
        if (cmd.Help) help = cmd.Help;

        return message.reply(`The command requires ${cmd.Args} arguments. You've provided ${args.length}...\n\`\`\`js\n${message.prefix}${cmd.name.toLowerCase()} ${cmd.usage.replace(/{p}/g, message.prefix)}\`\`\`{HELP}`.replace("{HELP}", help));
    };

    try {
        return cmd.exe(message, args);
    } catch (err) {
        message.client.x.postError(`Error executing Command [${cmd.name}]:`, err);
    };
};
