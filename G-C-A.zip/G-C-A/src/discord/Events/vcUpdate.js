const GCA = require('../../gca.js');
const Channels = require('../../Constants.js').Channels;
let Durations = {
    //discordID: { joinedAt:Number }
};

const timeSince = async function(time){
    if(!time) time = GCA.Disc.bot.readyAt;
    if(!time) time = Date.now() -1;
    time = Date.now() - time;

    let str = `HH hours, MM minutes, SS seconds.`
    str = str.replace('HH', Math.floor(time / 1000 / 60 / 60) % 24)
        .replace('MM', Math.floor(time / 1000 / 60) % 60)
        .replace('SS', Math.floor(time / 1000) % 60);

        //#region
    /*str = str.split(', ');
    let msg = [];

    for(x in str){
        let time = str[x]
        console.log(time)
        let dur = time.split(' ');
        console.log(dur)
        console.log(Number(dur))
        if(Number(dur) > 0){
            console.log('Number(dur) > 0')
            if(str.length == x && msg.length > 0) time = `and ${time}`;
            msg.push(time);
        };
    };

    if(msg.length == 0){
        msg = `0 seconds.`;
    }else{
        msg.join(', ');
    };
    return msg*/
        //#endregion
    return str;
};

module.exports = async function(oldState, newState){
    let ch = GCA.Disc.bot.channels.cache.get(Channels.error);
    let msg = `${newState.member.displayName.replace(/_/g, "\\_")} has {ACTION} {CHANNEL}.`;

    if (newState.channel && !oldState.channel) { //User joined a VC.
        msg = msg.replace('{ACTION}', 'joined').replace('{CHANNEL}', newState.channel.name);
        Durations[newState.member.id] = Date.now();

    } else if (!newState.channel && oldState.channel) { //User left a VC.
        msg = msg.replace('{ACTION}', 'left').replace('{CHANNEL}', oldState.channel.name);
        msg = msg + ` - \`Duration in ${oldState.channel.name}: ${await timeSince(Durations[oldState.member.id])}\``;
        delete Durations[oldState.member.id];

    } else if (newState.channel && oldState.channel) { //User changed VC's.
        if (newState.deaf && !oldState.deaf) return; //User was deafened.
        if (!newState.deaf && oldState.deaf) return; //User was undeafened.
        if (newState.mute && !oldState.mute) return; //User was muted.
        if (!newState.mute && oldState.mute) return; //User was unmuted.
        if (newState.streaming && !oldState.streaming) return; //User started streaming.
        if (!newState.streaming && oldState.streaming) return; //User stopped streaming.
        if (newState.selfVideo && !oldState.selfVideo) return; //User started video.
        if (!newState.selfVideo && oldState.selfVideo) return; //User stopped video.

        if(newState.channel.name === oldState.channel.name) await newState.client.GCA.Constants.logger({file:'vcUpdated', text: `\nOldState\n${JSON.stringify(oldState)}\n\nNewState\n${JSON.stringify(newState)}`});
        //await newState.client.GCA.Constants.logger({ file: 'vcUpdate', text: `\nOldState\n${JSON.stringify(oldState)}\n\nNewState\n${JSON.stringify(newState)}` });


        msg = msg.replace('{ACTION}', 'swapped from').replace('{CHANNEL}', `${oldState.channel.name} to ${newState.channel.name}`);
        msg = msg + ` - \`Duration in ${oldState.channel.name}: ${await timeSince(Durations[oldState.member.id])}\``;
        Durations[oldState.member.id] = Date.now();
    };

    ch.send(msg);
};
