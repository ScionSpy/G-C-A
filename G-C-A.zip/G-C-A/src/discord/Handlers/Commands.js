const fs = require('fs');
const { Collection } = require('discord.js');


class CommandHandler {

    #Commands = new Collection();
    constructor() {
        let cmdPath = `${process.cwd().replace(/[\\]+/g, '/')}/src/discord/_Commands`;

        fs.readdir(cmdPath, { require: 'utf8' }, (err, files) => {
            if (err) throw Error(err);

            //We now have all the files within the Commands folder.
            files.forEach(cmd => {
                if (!cmd.endsWith(".js")) return; //gets rid of any files/folders that don't end with/in ".js" file extension.

                // 'cmd' represents an individual file, or "Command" within the 'Commands' Directory.
                // 'ping.js'
                // 'status.js'

                let name;
                if (cmd.name) name = cmd.name.toLowerCase();
                //This is defined within the file.
                // if there is no name within the file, the file's own name is used.
                else name = cmd.split('.js')[0];

                cmd = require(cmdPath + '/' + cmd);

                try {
                    if (!cmd.exe) throw new Error(`cmd.exe function not found!`);

                    this.#Commands.set(name.toLowerCase(), cmd);
                    this[name] = cmd;
                    console.log(`Loaded Command {${name}}`);
                } catch (err) {
                    console.error(`\n[Cmd_Handler] failed to load Command {${name}}\n>> Error: ${err}\n`);
                };
            });
        });

        return this;
    };

    async get(cmd) {
        let xCmd = this.#Commands.get(cmd) || this.#Commands.find(c => c.aliases && c.aliases.includes(cmd));

        if (!xCmd) return false; //Command doesn't exist.
        else return xCmd;
    };
};


module.exports = CommandHandler;
