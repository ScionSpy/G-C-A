const constants = require('../constants.js');
//const RankList = constants.ranks;

class Constants {
    constructor(bot) {
        this.bot = bot;


        for (const key in constants) {
            this[key] = constants[key];
        };
    };

    async postError(str, err) {
        let ch = this.bot.channels.cache.get('1135329167571947534');
        if (!ch) throw new Error(`Client cannot access the GCA Errors channel!`);

        let msg;

        if (!err) msg = `<@213250789823610880>,\n\`\`\`js\n${str}\`\`\``;
        else msg = `<@213250789823610880>, ${str}\n\`\`\`js\n${err}\`\`\``

        ch.send(msg);
    };

    filterGuildMsg = async function (Member, msg) {
        let Guild = Member.guild;

        msg = await msg.replace(/{guildName}/g, Guild.name);
        msg = await msg.replace(/{guildname}/g, Guild.name);
        msg = await msg.replace(/{guildID}/g, Guild.id);
        msg = await msg.replace(/{guildid}/g, Guild.id);
        msg = await msg.replace(/{memberCount}/g, Guild.memberCount);
        msg = await msg.replace(/{membercount}/g, Guild.memberCount);
        msg = await msg.replace(/{members}/g, Guild.memberCount);

        msg = await msg.replace(/{@user}/g, Member);
        msg = await msg.replace(/{userTag}/g, Member.user.tag);
        msg = await msg.replace(/{usertag}/g, Member.user.tag);
        msg = await msg.replace(/{username}/g, Member.user.username);
        msg = await msg.replace(/{userID}/g, Member.user.id);
        msg = await msg.replace(/{userid}/g, Member.user.id);

        msg = await msg.replace(/\\n/g, `\n`); //The DB saves '\n' as '\\n' so have to fix it.

        return msg;
    };
};

module.exports = Constants;
