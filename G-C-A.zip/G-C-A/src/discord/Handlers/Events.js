const P = "../Events/";

const allowEvents = {
    //General Events
    message: true,              //Fired when a Message is posted. (In a Server or a DM)
    vcUpdate: true,             //Fired when a Guild Member joins/leaves a Voice Chat.

    //GuildServer Events
    guildMemberAdd: true,       //Fired when a GuildMember joines the server.
    guildMemberRemove: true,    //Fired when a GuildMember leaves the server.
    guildMemberUpdate: true,    //Fired when a GuildMember has been updated.
};

const eventHandlers = {
    memberJoined: require(P + "memberJoined"),
    memberLeft: require(P + "memberLeft"),
    memberUpdated: require(P + 'memberUpdated'),
    messageCreate: require(P + 'messageCreate'),
    //messageEdited: require(P+'messageEdited'),
    //messageDeleted: require(P+'messageDelted'),
    //updateGuild: require(P + 'updateGuild'),
    //updateUser: require(P + 'updateUser'),
    vcUpdate: require(P + 'vcUpdate'),
}

class Events {
    constructor(bot) {
        this.bot = bot;
        let event;
        try {
            this.bot.on('message', (msg) => {
                if (! allowEvents['message']) return;
                event = 'message';
                eventHandlers.messageCreate(msg);
            });

            this.bot.on('voiceStateUpdate', (Old, New) => {
                if(!allowEvents['vcUpdate']) return;
                event = 'voiceStateUpdate';
                eventHandlers.vcUpdate(Old, New);
            });

            //#region GuildMember Updates.
            this.bot.on("guildMemberAdd", (member) => {
                if (!allowEvents['guildMemberAdd']) return;
                event = 'memberJoined';
                if(!member.client) member.client = this.bot;
                eventHandlers.memberJoined(member)
            })
            this.bot.on("guildMemberRemove", (member) => {
                if (!allowEvents['guildMemberRemove']) return;
                event = 'memberLeft';
                eventHandlers.memberLeft(member)
            });

            this.bot.on("guildMemberUpdate", (oldMember, newMember) => {
                if (!allowEvents['guildMemberUpdate']) return;
                        event = 'memberUpdated';
                        eventHandlers.memberUpdated(oldMember, newMember);
                    })

           //#endregion

            //#region GuildUpdates
            /*this.bot.on('guildUpdate', (oldGuild, newGuild) => {
                event = 'guildUpdate';
                eventHandlers.updateGuild(oldGuild, newGuild);
            });*/
            //#endregion


        } catch (err) {
            console.error(event, err);
            if(event == "message") message.channel.send(err.stack, {code:'xl', split:true});
        };

        for (let k in eventHandlers) {
            console.log(`Loaded Event {${k}}`);
        };
    };
};

module.exports = Events
