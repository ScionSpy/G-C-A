let command = {
    name: "auth",
    aliases: ['authenticate'],
    //auth: "recruiter",
    Args: 1,
    usage: "\"Your In Game Name\""
};
module.exports = command;


command.exe = async function (message, args) {
    if(!message.client.GCA.DB.isRecruiter(message.member.displayName)) return message.reply('Command is currently unavailable to non-admins while it is being created.');

    let wowsMember = args.shift();
    let discMember = message.author.id;

    let dbMember = await message.client.GCA.DB.getMember(wowsMember);

    //if(dbMember.discord_id !== null || dbMember.clan_role >  )

    let bound = await message.client.GCA.DB.bindMember(wowsMember, discMember);
    let msg;

    try{
        if (bound !== true) {
            msg = "failed to bind the WoWs account to this account.... Not really sure why... (Database issues....)";
            if (typeof bound !== "undefined") msg = bound;

        } else {
            msg = "I've successfully bound these 2 accounts together!\n  Roles will now be adjusted automatically.";

            let guildMember = await message.guild.members.cache.get(discMember);
            try {
                if (guildMember.displayName !== wowsMember) await guildMember.setNickname(wowsMember, "Member verified their WoWs account.");
                await guildMember.roles.add(['1126377465741324435', '1137246581205258240'], "Member verified their WoWs account.");
            } catch (err) {
                if (err.msg == "Discord API Error: Missing Permissions") return message.channel.send(`Failed to update Discord Member '__**${guildMember.dsiplayName}'**__\n\`setNickname, or modify Roles.\` The member's highest role is either eqal to, or higher than mine!!`);
                message.channel.send(`Failed to update Discord Member:\n\n` +err.stack, { code: 'js', split: 1 });
            };


            //Add Rank role.
        };
        message.channel.send(msg, { split: 1 });

    }catch (err) {
        message.channel.send(err.stack, { code: 'js', split: 1 });
    };
};
