let command = {
    name:"ondisc"
};


command.exe = async function (message){
    let bot = message.client;

    let dMembers = [];
    await message.guild.members.fetch();
    dMembers = message.guild.members.cache.map(member => { return member.displayName });

    let members = await bot.GCA.Web.getClanMembers();
    members = members.members;
    let list = [];

    for (const ID in members) {
        let mem = members[ID];
        list.push(mem.account_name);
    };

    let msg = JSON.stringify(await filter(list, dMembers), null,4)

    message.channel.send(msg, {code:'js', split:1});
};

module.exports = command;



async function filter(wows, discord) {
    let conf = [];
    let unconf = [];
    for (let x = 0; x < wows.length; x++) {
        let found = false;
        let u = wows[x];

        for (let y = 0; y < discord.length; y++) {
            let m = discord[y]
            m = m.split(" ");
            m.shift();
            m = m.join(" ");
            if (m.toLowerCase() === u.toLowerCase()) found = true;
        };
        if (found) conf.push(u)
        else unconf.push(u);
    };
    conf.unshift(conf.length);
    unconf.unshift(unconf.length);
    return { conf:conf.sort(), unconf:unconf.sort() };
};
