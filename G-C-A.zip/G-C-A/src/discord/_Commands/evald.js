



let command = {
    name: 'evald',
    aliases: ['evd'],
    Access: 'Dev',
    EasterEgg: true,
    args: true
};

async function clean(evaled, bot) {
    if (evaled && evaled.constructor.name == "Promise") evaled = await evaled;

    if (typeof evaled !== "string") evaled = require("util").inspect(evaled);

    evaled = evaled
        .replace(/`/g, "`" + String.fromCharCode(8203))
        .replace(/@/g, "@" + String.fromCharCode(8203))
        .replace(bot.token, "INVALID-TOKEN");;

    return evaled;
};

command.exe = async function (message, args) {

    if (!args) return;

    //Define eval phrases
    const bot = message.client;
    const discord = require('discord.js');
    const e = new discord.MessageEmbed();
    const GCA = bot.GCA;
    const lastBattle = require("../../../seasons.json");

    try {
        let evaled = eval(args.join(" "));
        message.channel.send(await clean(evaled, message.client), { code: "js", split: true });
    } catch (err) {
        message.channel.send(`\`ERROR\` \`\`\`xl\n${await clean(err, message.client)}\n\`\`\``);
    }
};

module.exports = command;
