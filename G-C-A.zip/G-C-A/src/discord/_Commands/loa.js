let Embed = require('discord.js').MessageEmbed;
let Constants = require('../../Constants');
let _message;

let command = {
    name: "loa",
    auth: "recruiter",
    Args: 1,
    usage: "<@user|userid> <reason>"
};
module.exports = command;

async function padList(list){
    let paddedList = [];

    let longest = Math.max(...list.map(({ length }) => length));

    for(let x = 0; x<list.length; x++){
        paddedList.push(list[x].padStart(longest, ' '));
    };

    return paddedList;
};

async function catchBlock(list, embed){
    let names = {loa:[], loae:[]}; // Rank - Name
    let ranks = {loa:[], loae:[]};

    for (x = 0; x < list.length; x++) {
        let member = list[x];

        if(!member.loa.loaExempt){
            names.loa.push(member.name);
            ranks.loa.push(member.clan_role);
        }else{
            names.loae.push(member.name);
            ranks.loae.push(member.clan_role);
        };
    };

    let loaPaddedNames = await padList(names.loa);
    let loaList = [];

    for (x = 0; x < loaPaddedNames.length; x++) {
        loaList.push({name:loaPaddedNames[x], rank: ranks.loa[x]});
    };

    let loaePaddedNames = await padList(names.loae);
    let loaeList = [];

    for (x = 0; x < loaePaddedNames.length; x++) {
        loaeList.push({ name: loaePaddedNames[x], rank: ranks.loae[x] });
    };


    let loas = [];
    let loaes = [];

    if (loaList.length > 0) {
        loaList.sort((a, b) => {
            return (Constants.Ranks[b.rank] - Constants.Ranks[a.rank])
                || b.name.replace(' ', '').toLowerCase().localeCompare(a.name.replace(' ', '').toLowerCase())
        });
        for (let x = 0; x < loaList.length; x++){
            let mem = loaList[x];
            loas.push(`${mem.name} - ${Constants.clans_roles[mem.rank]}`); //clans_roles
        };
    };

    if (loaeList.length > 0) {
        loaeList.sort((a, b) => {
            return (Constants.Ranks[b.rank] - Constants.Ranks[a.rank])
                || b.name.replace(' ', '').toLowerCase().localeCompare(a.name.replace(' ', '').toLowerCase())
        });
        for (let x = 0; x < loaeList.length; x++) {
            let mem = loaeList[x];
            loaes.push(`${mem.name} - ${Constants.clans_roles[mem.rank]}`);
        };
    };




    embed.setTitle(`G-C-A "Leave of Absenties" list`);
    if (loas.length > 0) embed.addField('LoA List', `\`\`\`diff\n+ ${loas.join("\n+ ")}\`\`\``);
    if (loaes.length > 0) embed.addField('LoA-Exempt List', `\`\`\`diff\n+ ${loaes.join("\n+ ")}\`\`\``);
    embed.setFooter(`For more info: "${_message.prefix}loa list <name>"`);

    return embed;
};

command.exe = async function (message, args) {
    _message = message;

    if(args[0] == "list"){
        let list = await message.client.GCA.Disc.getLoAs();
        if(list.length == 0) return message.channel.send(`There are currently no members on any Leaves of Absences!`);


        let embed = new Embed()
            .setColor("yellow")
            .setTimestamp()
            .setAuthor(`**G-C-A** Gemini's Comerades in Arms`, message.guild.iconURL({dynamic:true}))
            //.setThumbnail(message.guild.iconURL())

        if(!args[1]){
            embed = await catchBlock(list, embed);
            return message.channel.send(embed);

        }else{
            let member;

            for(let x = 0; x<list.length; x++){
                let mem = list[x];
                if(mem.name.toLowerCase() === args[1].toLowerCase()) member = mem;
                if(member) break;
            };

            if(!member){
                embed = await catchBlock(list, embed);
                return message.channel.send(embed);
            };

            let Details = '';
            //Details = Details + `\ \ \ Authd By : ${mem.loa.auth}`;
            if(member.loa.loaExempt) Details = Details + `\n [IS LOA EXEMPT]`
            Details = Details + `\nStarted LoA : ${Math.floor((Date.now() - member.loa.start) / 1000 / 60 / 60 / 24)} Days Ago.`;
            Details = Details + `\nLast Battle : ${Math.floor(((Date.now() / 1000) - member.last_battle) / 60 / 60 / 24)} Days Ago.`;
            Details = Details + `\n\ Joined GCA : ${Math.floor(((Date.now() / 1000) - member.clan_joined) / 60 / 60 / 24)} Days Ago.`;
            Details = Details + `\n\ LoA Reason :\n\ \ \ ${member.loa.reason}`;


            embed.addField(`${member.name} - ${Constants.clans_roles[member.clan_role]}\n> Authd By : ${member.loa.auth}`, `\`\`\`js\n${Details}\`\`\``);

            return message.channel.send(embed);
        };
    };

    if (!args[1]) return message.reply(`The command requires 2 arguments.You've provided ${args.length}...\n\`\`\`js\n..${command.name} ${command.usage}\`\`\``);

    let member;
    if (message.mentions.users.first()){
        member = message.guild.members.cache.get(message.mentions.users.first().id).displayName;

    }else member = args[0];

    let LOAE = false;
    if(member == '+'){
        LOAE = true;
        member = args[1];

        if (!args[2]) return message.reply(`The LoA Exemption command requires 3 arguments.You've provided ${args.length}...\n\`\`\`js\n..${command.name} ${command.usage}\`\`\``);

        args.shift();
    };

    args.shift(); //Delete the first arg, be it an ID or mention.

    try{
        let loa;
        let wowsMember = await message.client.GCA.DB.getMember(member);
        let author = message.member.displayName;
        if (wowsMember) loa = await message.client.GCA.DB.setLoA(wowsMember.id, author, args.join(" "), LOAE);
        if(!wowsMember) return message.channel.send(`"${member}" not found on the GCA["Members"] Database.... Check your spelling, or ensure they're in the clan!`);
        if(wowsMember.discord_id){
            if(await message.guild.members.cache.get(wowsMember.discord_id) != 'undefined'){
                let guildMember = await message.guild.members.cache.get(wowsMember.discord_id);
                if (args[0].toLowerCase() != "null" && args[0].toLowerCase() != "clear") await guildMember.roles.add("1132055269648642168", `${author} has placed this member on LoA${LOAE ? '-Exempt' : ''} for: ${args.join(" ")}`);
                else await guildMember.roles.remove("1132055269648642168", `${author} has cleared this members LoA.`);
            }else message.channel.send(`\`Member does not have a conneted discord.\``);
        };

        let msg;
        if(loa){
            if (args[0].toLowerCase() != "null" && args[0].toLowerCase() != "clear") msg = `__**${member}**__ has been set to LoA${LOAE? '-Exempt' : ''} by __**${author}**__.\n> Reason: ${args.join(" ")}`;
            else msg = `Reinstated __**${member}**__ to active duty.`;

            // Set LoA Channel Topic to include list of current members on LoA.

            await message.client.GCA.Disc.postLoATopic();

            let loas = await message.client.channels.fetch(Constants.Channels.LoA);
            if(message.channel.id != loas.id) loas.send(msg.split('\n')[0]);
        }else{
            msg = `:warning: Failed to set __**${member}**__ on LoA${LOAE ? '-Exempt' : ''}.....`;
        };

        message.channel.send(msg, { split: 1 });

    } catch (err) {
        message.channel.send(err.stack, { code: 'js', split: 1 });
    };
};
