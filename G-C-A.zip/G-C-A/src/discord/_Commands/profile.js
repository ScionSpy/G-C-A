let command = {
    name: "profile",
    aliases: ['user'],
    //auth: "recruiter",
    Args: 1,
    usage: "<memberName|@user|userID>"
};
module.exports = command;


command.exe = async function(message, args){
    let tag = args.shift();
    
};
