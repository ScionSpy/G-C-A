let command = {
    name: "unbind",
    aliases: ['unverify'],
    auth:"recruiter",
    Args:1,
    usage:"<wowsUser>"
};
module.exports = command;


command.exe = async function(message,args){
    let wowsMember = args.shift();
    let notClan = args.shift();

    try{
        let bound;

        let wowsID = await message.client.GCA.Web.playerLookup(wowsMember, true);

        if (notClan == "x") bound = await message.client.GCA.DB.unbindMember(wowsMember, wowsID[0].account_id);
        else bound = await message.client.GCA.DB.unbindMember(wowsMember);

        let msg;

        if (bound !== true) {
            msg = "failed to unbind the WoWs account to this account.... Not really sure why... (Database issues....";
            if (typeof bound !== "undefined") msg = bound;

        } else {
            msg = "I've successfully unbound these 2 accounts together!\n  Roles will now be removed.";
            try {
                let guildMember = await message.guild.members.cache.find(member => { if (member.displayName.split(' ').pop() === wowsMember) return member });
                if (notClan == "x") await guildMember.roles.remove(['1137246581205258240'], "Member unverified.");
                else await guildMember.roles.remove(['1126377465741324435', '1137246581205258240'], "Member unverified.");
            } catch (err) {
                if (err.msg == "Discord API Error: Missing Permissions") return message.channel.send(`Failed to update Discord Member '__**${guildMember.dsiplayName}'**__\n\`setNickname, or modify Roles.\` The member's highest role is either eqal to, or higher than mine!!`);
                message.channel.send(`Failed to update Discord Member:\n\n` + err.stack, { code: 'js', split: 1 });
            };

        };


        message.channel.send(msg, { split: 1 });
    }catch(err){
        console.error(err)
        //message.channel.send(err.stack, {code:'js',split:1});
    };
};
