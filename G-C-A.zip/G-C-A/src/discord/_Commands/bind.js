let command = {
    name:"bind",
    aliases:['verify'],
    auth:"recruiter",
    Args:2,
    usage:"<wowsUser> <@user|userid>"
};
module.exports = command;


command.exe = async function(message,args){
    let member;

    let wowsMember = args.shift();

    if (message.mentions.users.first()) member = message.mentions.users.first().id;
    else member = args[0];
    args.shift(); //Delete the first arg, be it an ID or mention.

    let notClan = args.shift();

    try{
        let bound;

        let wowsID = await message.client.GCA.Web.playerLookup(wowsMember, true);
        bound = await message.client.GCA.DB.bindMember(wowsMember, member, wowsID[0].account_id);

        if(notClan != "x") bound = await message.client.GCA.DB.bindMember(wowsMember, member);
        let msg;

        if (bound !== true){
            msg = "failed to bind the WoWs account to this account.... Not really sure why... (Database issues....";
            if(typeof bound !== "undefined") msg = bound;

        }else{
            msg = "I've successfully bound these 2 accounts together!\n  Roles will now be adjusted automatically.";

            let guildMember = await message.guild.members.cache.get(member);
            if(!guildMember) guildMember = await message.guild.members.fetch(member);

            try{
                if(guildMember.displayName !== wowsMember) await guildMember.setNickname(wowsMember, "Member verified their WoWs account.");
                if (notClan == "x") await guildMember.roles.add(['1137246581205258240'], "Member verified their WoWs account.");
                else await guildMember.roles.add(['1126377465741324435','1137246581205258240'], "Member verified their WoWs account.");
            } catch (err) {
                if (err.msg == "Discord API Error: Missing Permissions") return message.channel.send(`Failed to update Discord Member '__**${guildMember.dsiplayName}'**__\n\`setNickname, or modify Roles.\` The member's highest role is either eqal to, or higher than mine!!`);
                message.channel.send(`Failed to update Discord Member:\n\n` + err.stack, { code: 'js', split: 1 });
            };


            //Add Rank role.
        };


        message.channel.send(msg, {split:1});

    }catch(err){
        //message.channel.send(err.stack, {code:'js',split:1});
        console.error(err)
    };
};
