const DB = require('../../Database/index.js');
const cmd = {
    name:'msgd',
    auth:"recruiter",
    args:1,
    usage: "<@user> [Admin Note]"
};


cmd.exe = async function(message,args){
    let member;
    if(message.mentions.members.first()) member = message.mentions.members.first().displayName.replace(/_/g, '\\_');
    else member = args[0];
    if(!member) return message.reply(`Please mention the user you messaged.`);

    let Member = await DB._Get("Inactives", {name:member});
    Member = Member[0];
    if (!Member) return message.reply(`I'm sorry, but **${member}** is not on the inactives list....`);

    args.shift(); //Delete the member;
    let note = args;
    let action = {
        adminMsg: false, //True or false
        adminNote: null, // null or string
    };

    if(note[0] != "clear" && note[0] != "null"){
        action.adminMsg = true;
        action.adminNote = note.join(' ');
    };

    let results = await DB._Edit('Inactives', { name: Member.name}, action);
    if (results.acknowledged){
        if(action.adminMsg) message.channel.send(`Alright! I've set that user as contacted by admin!${note.length > 0 ? `\nAdmin Note: \`${note.join(' ')}\`` : ''}`);
        else message.channel.send(`Ok...?? I've cleared the Admin Msg status on that User.....?`);
    }else{
        message.channel.send(`There was some error with that request....\n\`\`\`xl\n${results}\`\`\``);
    };
};



module.exports = cmd;
