const Discord = require('discord.js');
let command = {
    name: "send",
    aliases: ['msg'],
    auth: "recruiter",
    Args: 2,
    usage: "<userid> <string>"
};
module.exports = command;

command.exe = async function(message, args){
    const GCA = message.client.GCA;
    let userid = args.shift();

    // ToDo:
    // // Is USER ID a numer (NaN)

    let User = await message.client.users.fetch(userid);
    if(!User) return message.channel.send(`"\`${userid}\`" is not accosiated with a Discord User....\n  Double check the ID you're using!`);

    let Author = await GCA.DB._Get("Members", { discord_id: message.author.id }, { name: 1, clan_role: 1, active: 1 });
    Author = Author[0];

    let gcaGuild = await message.client.guilds.fetch(message.client.GCA.Constants.Guild_ID);


    let embed = new Discord.MessageEmbed();
    embed.setAuthor(`Incoming Message!`);
    embed.setThumbnail(message.author.avatarURL({ dynamic: true }));
    embed.setTitle(`${Author.name} - ${GCA.Constants.clans_roles[Author.clan_role]}`);
    embed.setColor("GREEN");
    embed.setTimestamp();
    embed.setDescription(args.join(" "));
    if (message.attachments.first()) {
        embed.setImage(message.attachemnts.first())
    };
    embed.setFooter(gcaGuild.name, gcaGuild.iconURL({ dynamic: true }));

    User.send(embed)
    .then(async () =>{
        let USER = User.username;

        let wowsMember = await GCA.DB._Get("Members", { discord_id: User.id }, { name: 1, clan_role: 1, active: 1 });
        if(wowsMember){
            wowsMember = wowsMember[0];
            let Active = wowsMember.active ? "Enlisted " : "";
            USER = `${Active}${wowsMember.name} [ ${GCA.Constants.clans_roles[wowsMember.clan_role]} ]`;
        };

        embed.setAuthor(`Message sent to: ${USER}\n(${User.id})`);

        message.client.channels.fetch(GCA.Constants.Channels.DM)
        .then(ch => { ch.send(embed) })
        .catch(err => { message.channel.send(`:warning: Unable to send DM Posting Log to direct_messages channel!!\n\`\`\`js\n${err.stack}\`\`\``); })
    })
    .catch(err => {message.channel.send(`:warning: Unable to send Direct Message!!\n\`\`\`js\n${err.stack}\`\`\``)});
};
