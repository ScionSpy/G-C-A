const fetch = require('node-fetch');
const Discord = require('discord.js');

let command = {
    name: 'upload',
    Access: 'Dev',
    EasterEgg: true,
    args: true
};
module.exports = command;


const Levels = {
    1: 'I',
    2: 'II',
    3: 'III',
    4: 'IV',
    5: 'V',
    6: 'VI',
    7: 'VII',
    8: 'VIII',
    9: 'IX',
    10: 'X',
    11: '★', //★ // ☆
};

const ShipClass = {
    'AirCarrier': 'AC',
    'Battleship': 'BB',
    'Cruiser': 'CC',
    'Destroyer': 'DD',
    'Submarine': ''
};

const Leagues = {
    1: "Typhoon",
    2: "Storm",
    3: "Gale",
    4: "Squall",
};


command.exe = async function(message, args){
    const file = message.attachments.first()?.url;
    if (!file) return message.channel.send('No attached file found.\n  You can create one from `https://clans.worldofwarships.com/api/ladder/battles/?team=1` - team = 1 or 2 (Alpha/Bravo)');

    if (args[0] == "live") channel = message.guild.channels.cache.get('1152409627795922944');
    else channel = message.channel;

    try {
        message.channel.send('Attempting to load the file...');

        // fetch the file from the external URL
        const response = await fetch(file);

        // if there was an error send a message with the status
        if (!response.ok)
            return message.channel.send(
                'There was an error fetching the file:',
                response.statusText,
            );

        // take the response stream and read it to completion
        let battles = await response.text();
        let lastBattle;

        if (battles) {
            battles = JSON.parse(battles);
            //console.log(battles[0]);

            let Team;
            let Ship_IDs = {};
            let Embeds = [];
            let counts = { wins: 0, losses: 0 };


            let Now = Date.now();
            let hrLimit = 1000 * 60 * 60 * 19; //19;        // Previous days battles;
            let battlesSince = new Date();
            battlesSince.setTime(Date.now() - hrLimit);
            console.log(`>> Fetching battles since: ${battlesSince}`);

            for (let x = 0; x < battles.length; x++) {
                let battle = battles[x];


                let battleTime = Date.parse(battle.finished_at);

                if ((Now - battleTime) > hrLimit){
                    lastBattle = (Now-battleTime) /1000 /60 /60 /24
                    break;
                };

                //if(await DB.GetClanBattle(battle.id) != null) break;
                //else await DB.uploadClanBattle(battle);

                let GCA = null;
                let opp = null;


                let players = {
                    GCA:[],
                    opp:[]
                };

                for (let y = 0; y < battle.teams.length; y++) {
                    let team = battle.teams[y];

                    team.Rankings = `${Leagues[team.league]} ${Levels[team.division]} (${team.division_rating } / 100)`;

                    if (team.clan_id === 1000101905) GCA = team;
                    else opp = team;

                    for (let z = 0; z < team.players.length; z++) {
                        let player = team.players[z];
                        delete player.ship.icons;
                        //delete player.vehicle_id;
                        let ShipType;
                        if(!Ship_IDs[player.vehicle_id]){
                            ShipType = await message.client.GCA.Web.getShipType(player.vehicle_id);
                            Ship_IDs[player.vehicle_id] = ShipType.type;
                        };
                        ShipType = Ship_IDs[player.vehicle_id];

                        let survived;
                        player.survived ? survived = '+' : survived = '-';

                        let item = `${player.name}\n${survived} ${Levels[player.ship.level]} (${ShipClass[ShipType]}) ${player.ship.name}`;
                        if (team.clan_id === 1000101905) players.GCA.push(item);
                        else players.opp.push(item);
                    };
                };

                let Result = GCA.result != null ? GCA.result : null;
                if(Result === "victory"){
                    Result = "Victory!";
                    counts.wins++
                }else{
                    Result = "Defeat!";
                    counts.losses++
                };

                let Delta = GCA.rating_delta;
                if (Delta > 0) Delta = `+${GCA.rating_delta}`;
                Team = GCA.team_number == 1 ? "Alpha" : "Bravo";

                let Ranking = `${Team} Div: ${Leagues[GCA.league]} ${Levels[GCA.division]} (${GCA.division_rating}/100)`;
                let Stage;
                if(GCA.stage !== null){
                    Stage = {};

                    if(GCA.stage.type == "demotion"){
                        if (GCA.stage.target == "league") Stage.Title = `Struggle to stay in the League.`;
                        else Stage.Title = `{Stage_Demotion_Division_TItle.Text}`;

                    } else { //We're promoting!!
                        if (GCA.stage.target == "league") Stage.Title = `{Stage_Promotion_League_TItle.Text}`;
                        else Stage.Title = `{Stage_Promotion_Division_TItle.Text}`;
                    };

                    Stage.Status = [`[]`,`[]`, `[]`, `[]`, `[]`];

                    for(let x = 0; x < GCA.stage.progress.length; x++){
                        let s = GCA.stage.progress[x];
                        if (s == "victory") Stage.Status[x] = "★ ";
                        else Stage.Status[x] = "✩ ";
                    };


                };

                let _Stage = ``;

                let color = GCA.result === "victory" ? "228B22" : "800000";

                const Embed = new Discord.MessageEmbed();
                Embed.setTitle(`${Result} (${Delta}) on ${battle.map.name}\n${Ranking}${_Stage}`);
                Embed.setAuthor(message.guild.name, message.guild.iconURL());
                Embed.setColor(color);
                Embed.setTimestamp(battle.finished_at);

                if(Stage) Embed.addField(Stage.Title, `\`\`\`js\n${Stage.Status.join(" ")}\`\`\``);
                Embed.addField(`[${GCA.claninfo.tag}]\n${GCA.claninfo.name}\n• ${GCA.Rankings}`, `\`\`\`diff\n${players.GCA.join("\n\n")}\`\`\``,true);
                Embed.addField(`[${opp.claninfo.tag}]\n${opp.claninfo.name}\n• ${opp.Rankings}`, `\`\`\`diff\n${players.opp.join("\n\n") }\`\`\``,true);

                Embeds.unshift(Embed);
            };

            if(Embeds.lengrh == 0) return channel.send(`No Battles found. (last battle was ${lastBattle} hrs ago...`)
            for(let x = 0; x< Embeds.length; x++){
                channel.send(Embeds[x]);
            };
            channel.send(`Tonights Stats; ${Team} Div:\`\`\`js\n  Wins : ${counts.wins}\nLosses : ${counts.losses}\`\`\`See: https://clans.worldofwarships.com/clan-battles/history`);
        };
    } catch (error) {
        console.log(error);
    }
};


