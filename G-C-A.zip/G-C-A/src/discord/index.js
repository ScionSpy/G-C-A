const Ranks = require('../Constants.js').Ranks;
const Ranks_S = require('../Constants.js').Ranks_Short;
const Roles = require('../Constants.js').clans_roles;
const Channels = require('../Constants.js').Channels;
const { MessageMentions: { USERS_PATTERN } } = require('discord.js');
const https = require('https');
const { postWebhook } = require('../Constants.js');

const loa_includeExmept = false;

const Disc = {boot:true};
module.exports = Disc;

/*const Channels = {
    member_updates:"1136014419567067166", // #member_updates -- Join/Leaves
    rank_updates: "1136014419567067166", // #member_updates -- Promo/Demotions
    inactive:"1135329167571947534", //testing grounds
    loa:"1126377466399826036", //abcense_with_leave
    members:"1135329167571947534", //testing grounds
};*/

const GuildID = '1126377465741324429';
const Role_IDs = require('../Constants.js').Role_IDs;

Disc.Init = async function(bot){
    Disc.bot = bot;
    delete Disc.Init;

    await bot.guilds.fetch('1126377465741324429');
    await bot.guilds.cache.get('1126377465741324429').members.fetch();
    return Disc;
};

let Console_Embeds = [];
Disc.Console2 = async function message(content, holdPost = false) {
    console.log(content
        .replace('```xl', '')
        .replace('```', '')
        , ">>> DISCORD_CONSOLE <<<"
    );


    Console_Embeds.push({
        description: content,
        //timestamp: true
    })

    if (holdPost && Console_Embeds.length != 10) return Console_Embeds;
    let promise = await new Promise(async r => {
        let d = JSON.stringify({
            embeds: Console_Embeds
        });
        let req = https.request(Disc.bot.GCA.Constants.Webhooks['playerUpdates'], {
            headers: {
                "Content-type": "application/json",
                "Content-length": Buffer.byteLength(d)
            },
            method: "POST"
        }, r);
        req.write(d);
    });

    Console_Embeds = [];
    return promise;
};


Disc.getUserFromMention = async function(mention, wantedKeys) {
    // The id is the first and only match found by the RegEx.
    const matches = await mention.matchAll(USERS_PATTERN).next().value;

    // If supplied variable was not a mention, matches will be null instead of an array.
    if (!matches) return;

    // The first element in the matches array will be the entire mention, not just the ID,
    // so use index 1.
    const id = matches[1];
    if(wantedKeys) return id;


    let results = {};

    let user = Disc.bot.users.cache.get(id);
    for(key in wantedKeys){
        let value = wantedKeys[key];
        results[key] = value;
    };

    return results;
}

const getChannel = async function(ch){
    if(Channels[ch]) ch = Channels[ch];
    else throw new Error(`Channel ${ch} does not exist!`);
    return await Disc.bot.channels.fetch(ch);
};

const getMember = async function(member = {id:null, name:null}){

    let guild = await Disc.bot.guilds.cache.get('1126377465741324429');
    let Members = await guild.members.fetch();
    let mem;

    if(member.id){
        mem = await guild.members.cache.get(member.id);

    }else if(member.name){
        mem = await Members.find(m => { return m.displayName.includes(member.name)});
    }else{
        throw new Error(`getMember() requires an id or name paramater! Got: ${member}`);
    };

    return mem;
};

let ExemptedPlayers = [
    "gemini66", // Discord: "Gemini66"
    "Gemini316",
    "ShadowSpyy",
    "BejebaSpy",
    "bilman39"
];
let clanlessPlayer = false;
Disc.updateVerified = async function(){
    let results = [];
    let discoMembers = await Disc.bot.guilds.cache.get('1126377465741324429').members.cache;
    let verified = await Disc.bot.GCA.DB._Get("Verified");
    for (let k in verified) {
        let player = verified[k];
        if(!ExemptedPlayers.includes(player.name)){

            let discoMem = await discoMembers.get(player.discord_id);
            // really only need nickname and roles....

            if (!discoMem){
                // Stop if this user isn't on the server...
                // Perhaps new db field "On Server".
                // this would trip this now and set it to 'false';
            }else{
                let playerData = await Disc.bot.GCA.Web.search(player.name, true);
                wows = playerData[player.name];

                let name;
                let oldname;
                if (wows.clan) {
                    if (wows.clan.tag === 'G-C-A') name = `${Disc.bot.GCA.Constants.Ranks_Short[wows.role]} ${wows.account_name}`;
                    else name = `[${wows.clan.tag}] ${Disc.bot.GCA.Constants.Ranks_Short[wows.role]} ${wows.account_name}`;
                } else name = wows.account_name;

                if (discoMem.nickname === name){
                    // Stop if the users Discord name matches what it should be in-game.
                    //This means his discord name currently represents his clan, and rank correctly.
                    //Otherwise, we need to update that!!
                }else{
                    oldname = discoMem.nickname;
                    if(!wows.clan || !name.startsWith('[')) clanlessPlayer = true;

                    let status = await discoMem.setNickname(name, `Updating name to match in-game`).catch(async (err) => {
                        //postWebhook('playerUpdates', `> > ⚠ Failed to update __**${oldname}**__ to __**${name}**__ !!\n\`\`\`js\n${err.message}\`\`\``, true);
                        await Disc.Console2(`> > ⚠ Failed to update __ ** ${ oldname }** __ to __ ** ${ name }** __!!\n\`\`\`js\n${err.message}\`\`\``, true);
                    });
                    if (status) {
                        //postWebhook('playerUpdates', `> > Updated Discord name Old: __**${oldname}**__ | New: __**${name}**__`, true);
                        Disc.Console2(`> > Updated Discord name Old: __**${oldname}**__ | New: __**${name}**__`, true);
                    };

                    //Modify Roles if that of an ally clan!


                    results.push({ old: oldname, new: name });
                }; //Discord name does NOT match in-game info.
            }; //Has Discord on server
        }; //Exmpted Players
    }; //Verified members loop.
    //await postWebhook('gcaConsole', `Non-GCA Updater completed!  |  Ran ${results.length} updates`);
    await Disc.Console2(`Non-GCA Updater completed!  |  Ran ${results.length} updates`);
    //await postWebhook('playerUpdates', `Non-GCA Updater completed!  |  Ran ${results.length} updates`);

    if (clanlessPlayer){
        await Disc.bot.channels.cache.get('1222751535159578717').send(`Clanless member detected!!\n  <@&1126377465741324437> please review the above changes!!`);
        clanlessPlayer = false;
    };
    return {count: results.length, results};
};

Disc.postInactives = async function(members){
    let inactive = members.inactive;
    let active = members.nowActive;
    let ch = await getChannel("inactives");
    let LoAs = await Disc.getLoAs();

    let list = {
        loa: [`\n__**Inactive Members on LoA**__`],
        loaX: [`\n__**Active Members on LoA**__`],
        inactive: ['\n:x:  __**Inactive G-C-A Members**__  :x:'],
        newInactive: ['\n:warning:  __**Newly Inactive G-C-A Members**__  :warning:'],
        active: ['\n:ok_hand:  __**Returning G-C-A Members**__  :ok_hand:'],
        discord_users:{}
    };

    let names = [];

    for (const mem in inactive){
        let member = inactive[mem];
        let disc = "";
        if (!member.discord_id){
            disc = ":exclamation:";
        }else{
            if (member.dmLocked) disc = disc + "🔇";
            if (member.adminMsg) disc = disc + "[✉] ";
        };
        let INACTIVE = Math.ceil(member._lastBattle) - 7;
        let msg = `${disc}__**${member.name.replace(/_/g, "\\_")}**__ has exceeded the inactivity period by: __**${INACTIVE} days**__! (${INACTIVE +7}) \`(Joined Clan : ${Math.floor(((Date.now() / 1000) - member.joined) / 60 / 60 / 24)} Days ago.)\``;

        if(member.loa){
            let D = new Date(member.loa.start);
            let date = `${D.getFullYear()}-${D.getMonth()+1}-${D.getDate()}`;
            let startedLoa = Math.floor((Date.now() - member.loa.start) / 1000 / 60 / 60 / 24);
            let postIt = true;

            if (member.loa.loaExempt && !loa_includeExmept) postIt = false;

            if(postIt) list.loa.push(`> ${member.loa.loaExempt ? ':shield:' : ''}__**${member.name.replace(/_/g, "\\_") }**__ was set to LoA by __**${member.loa.auth}**__ on __**${date}**__. (\`${startedLoa} Days ago.\`)\n> > __**Reason**__: ${member.loa.reason}\n`);
            names.push(member.name.replace(/_/g, "\\_"));

        }else if(member.isOld === false){
            list.newInactive.push(`> ${msg}`);
            if (!member.loa || !member.discord_id) await Disc.sendInactiveNotice(member.name);
        }else{
            if ((INACTIVE +7) > 14) msg = `:boot: `+msg
            list.inactive.push(`> ${msg}`);
            if (!member.loa || !member.discord_id) await Disc.sendInactiveNotice(member.name);
        };

        if(disc && !member.loa){
            list.discord_users[member.discord_id] = member.name;
        };
    };

    // Handle Active LoA members.
    for(const mem in LoAs){
        let member = LoAs[mem];
        if (!names.includes(member.name.replace(/_/g, '\\_'))){
            let D = new Date(member.loa.start);
            let date = `${D.getFullYear()}-${D.getMonth() + 1}-${D.getDate()}`;
            let startedLoa = Math.floor((Date.now() - member.loa.start) / 1000 / 60 / 60 / 24);

            if(loa_includeExmept) list.loaX.push(`> ${member.loa.loaExempt ? ':shield:' : ''}__**${member.name.replace(/_/g, "\\_")}**__ was set to LoA by __**${member.loa.auth}**__ on __**${date}**__. (\`${startedLoa} Days ago.\`)\n> > __**Reason**__: ${member.loa.reason}\n`);
        };
    };


    for (const mem in active) {
        let member = active[mem];
        list.active.push(`> ${(member.loa && !member.loa.loaExempt) ? `<@213250789823610880>, ` : ''}**${member}** is no longer inactive!`);
    };

    let msg = [];
    let _loa = false;

    if(Disc.boot){
        delete Disc.boot;
        msg.push(`**The Automaton has just rebooted! Refreshing inactivty lists!**`);

        let LoAs = await Disc.bot.GCA.DB._Get("Members", { active: true }, { loa: 1 });
        let count = 0;
        let exempt = 0;
        for(x=0;x<LoAs.length;x++){
            if(LoAs[x].loa) count++;
            if(LoAs[x].loa?.loaExempt) exempt++;
        };
        if(count > 0){
            _loa = true;
            if(!loa_includeExmept) count = count -exempt;
            msg.push(`\n**__========__ Start LoA's __========__**\n\n**There ${count > 1 ? "are" : "is"} ${count} ${count > 1 ? "members" : "member"} actively on the LoA's!**\n> \`..loa list\` for more info!`);
        };
    };

    if (list.loa.length > 1) {
        msg = msg.concat(list.loa);
    };

    if (list.loaX.length > 1) {
        msg = msg.concat(list.loaX);
    };

    if(_loa) msg.push(`\n**__========__ End LoA's __========__**`);

    if(list.inactive.length == 1 && list.newInactive.length == 1){
        msg.push(`\n\n**All G-C-A members are currently active!**`);
    }else{
        if (list.inactive.length > 1) {
            msg = msg.concat(list.inactive);
        };

        if (list.newInactive.length > 1) {
            msg = msg.concat(list.newInactive);
        };
    };

    if(list.active.length > 1){
        msg = msg.concat(list.active);
    };


    await ch.send(msg.join("\n"), { split: 1 });

    // Update LoA topic list. In the event an LoA left the clan.
    let posted = await Disc.postLoATopic(); //I think it's redundant.... but JUST in case.
    if(posted) console.log('Fired "Redundant" loaTopic catch... [discord/index.js_Disc.postInactives]');
    //send messages to discord accounts {list.discord_users}
};

Disc.postUpdates = async function(updates){
    // updates = { new:[], returning:[], updated:[], removed:[] };

    let memberUpdates = [];
    let rankUpdates = [];

    for(let x = 0; x<updates.new.length;x++){
        let mem = updates.new[x];

        memberUpdates.push(`__**${mem.account_name.replace(/_/g, "\\_") }**__ has joined the clan!`);
    };

    for (let x = 0; x < updates.returning.length; x++) {
        let mem = updates.returning[x];

        //memberUpdates.push(`__**${mem.name}**__ has returned to the clan after {Math.floor((Date.now() /1000) - mem.left_at) /60/60/24} days!`);
        memberUpdates.push(`__**${mem.account_name}**__ has returned to G-C-A!`);
    };

    for (let x = 0; x < updates.removed.length; x++) {
        let mem = updates.removed[x];
        let resWarn = ``;

        if(mem.discord_id){ //if disc verified.
            //Remove Perms.

            let member = await getMember({ id: mem.discord_id });
            if(member){
                let res = await Disc.RemovePerms(member);
                if (res !== true) resWarn = `\n> :warning::warning: **Could not remove Discord Roles!!**\n>> ${res}`;
                res = await Disc.AddPerms(member, Disc.bot.GCA.Constants.Role_IDs_byName["__clan_friends"]);
                if (res !== true) resWarn = `\n> :warning::warning: **Could not Add Discord Roles!!**\n>> ${res}`;

                res = await Disc.RemoveClan(member);
                if (res !== true) resWarn = `\n> :warning::warning: **Could not Removed Discord Clan Tags!!**\n>> ${res}`;

                await Disc.bot.GCA.DB._Edit("Members", {name:mem.account_name}, {hasBeenWelcomed:false});
            };
        };
        memberUpdates.push(`:warning: __**${mem.name}**__ has left the clan!${resWarn}`);

        // Update LoA topic list. In the event an LoA left the clan.
        await Disc.postLoATopic();
    };

    for (let x = 0; x < updates.updated.length; x++) {
        let mem = updates.updated[x];
        let member = await getMember({ name: mem.name});
        if(member){
            let type = `was promoted`;

            try{
                if(!mem.wasPromoted){ //Demote
                    type = `was demoted`;
                    await Disc.RemovePerms(member, mem.oldRole);
                    await Disc.AddPerms(member, mem.newRole);

                } else { //Promote
                    await Disc.AddPerms(member, mem.newRole);
                    await Disc.RemovePerms(member, mem.oldRole);

                };
                await member.setNickname(mem.name, `Member ${type}`);

            } catch (err) {
                let ch = await getChannel('error');
                ch.send(`<@213250789823610880>, Error editing user: "${mem.name.replace(/_/g, "\\_") }" from a "${mem.oldRole} to "${mem.newRole}`);
                console.error(err)
            };

            rankUpdates.push(`__**${mem.name.replace(/_/g, "\\_")}**__ was **${type}** from __**${Roles[mem.oldRole]}**__ to __**${Roles[mem.newRole]}**__`);
        };
    };



    if (memberUpdates.length > 0) {
        let  ch = await getChannel('member_updates');
        await ch.send(`__**Member Changes**__\n> ${memberUpdates.join('\n> ')}`, { split: 1 });
    };
    if(rankUpdates.length > 0){
        let ch = await getChannel('rank_updates');
        await ch.send(`__**Rank Changes**__\n> ${rankUpdates.join(`\n> `)}`, {split:1});
    };
};




Disc.sendInactiveNotice = async function (player, inactive) {
    let ch = await getChannel("inactives");

    let getDate = async function (time) {
        return Math.ceil(((Date.now() / 1000) - time) / 60 / 60 / 24);
    };

    let setNoticeCount = async function(newCount){
        if(!newCount || isNaN(newCount)) throw new Error(`newCount nota Number!`);
        let adminMsg = false;
        return await Disc.bot.GCA.DB._Edit("Inactives", { name: player }, { noticeCount: newCount, adminMsg, adminNote:null});
    };

    let noticeCount = await Disc.bot.GCA.DB._Get("Inactives", { name: player }, { noticeCount: 1 });
    if (!noticeCount) noticeCount = 0;
    else noticeCount = noticeCount[0].noticeCount;

    let wowsMem = await Disc.bot.GCA.DB.getMember(player);

    if (!inactive) inactive = await getDate(wowsMem.last_battle);
    let joined = await getDate(wowsMem.clan_joined);
    if (!wowsMem.discord_id || wowsMem.dmLocked){
        let reason = '';

        if (!wowsMem.discord_id) reason = 'a synced discord account.';
        else if(wowsMem.dmLocked) reason = 'an open DM.';

        if (noticeCount == 0){
            await setNoticeCount(1);
            return ch.send(`:exclamation: ${player.replace(/_/g, "\\_") } does not have ${reason}\n> \`Days_In_Clan : ${joined} || Days_Inactive : ${inactive}\``)
        };
    };

    let dMember = null;
    try{
        dMember = await Disc.bot.guilds.cache.get(GuildID).members.fetch(wowsMem.discord_id);
    }catch(err){
        //Active GCA Member left the discord server.
        if (err.message == "Unknown Member") return ch.send(`\`>>>\` :warning: __**${wowsMem.name}**__ (<@${wowsMem.discord_id}>) has been marked as **AWOL**! :warning:`);

    };

    let msg;

    if((inactive < 13 && inactive >= 9) && noticeCount == 0){
        msg = `Hello __**${wowsMem.name.replace(/_/g, "\\_")}**__, you've been with __G-C-A for ${joined} days.__\n  I'm reaching out to you because you've __been inactive for ${inactive} days__.\n  This is **${inactive - 7} day(s) longer than we accept.**\n    If you need a leave of absence please make a post in <#1126377466399826036> or contact an officer of the clan.\n\n We require you to participate in at least one (1) battle per week if you have not submitted for an LoA.\n If you fail to partake in a battle or post in <#1126377466399826036> before your 14'th day of inactivity you risk being removed from the clan.`;

        await setNoticeCount(1);
    }else if (inactive >= 13 && noticeCount == 1){
        msg = `Hello __**${wowsMem.name.replace(/_/g, "\\_")}**__, you've been with __G-C-A for ${joined} days.__\n  I'm reaching out to you because **you've gone inactive**, not posted in our <#1126377466399826036> channel, and have **exceeded the allowed limit of inactive days!**\n\n  Please reach out to us if you intend to remain in the clan, __**you're now at risk of being removed!**__`;

        await setNoticeCount(2);
    };

    if (!msg) return; //await ch.send(`:warning: Aborted \`Disc.sendInactiveNotice("${player}", {inactive:${inactive}, noticeCount:${noticeCount}})\` :warning:`);


    if(dMember){
        //await dMember.send(msg +`\n\n  __*\`Responses to this channel are not monitored, please respond using our G-C-A discord!\`*__`)
        if(typeof dMember.send != "function"){
            console.log(`dMember.send is not a function`, dMember);

            ch = await getChannel("error");

            console.log(dMember)

            await ch.send(JSON.stringify(dMember), {split:true, code:'js'});
            await ch.send(JSON.stringify(wowsMem), { split: true, code: 'js' });
            return await ch.send(`<@213250789823610880>, <@268520118869295105>,\n There was an error sending a discord User an inactivty notice!\n> \`dMember.send is not a function!\`\ndMember = \n\`\`\`js\n${JSON.stringify(dMember),null,4}\`\`\``, {split:true});
        };

        await dMember.send(msg)
        .then(() =>{
            ch.send(`> Sent __**${wowsMem.name.replace(/_/g, "\\_")}**__ a \`${inactive} day\` inactivity notice!`);
        })
        .catch(async (err) => {
            if (err.message === "Cannot send messages to this user"){
                await ch.send(`:warning::Warning: Could not send a message to __**${wowsMem.name.replace(/_/g, "\\_")}**__! Their DM's may be closed!!`);
                await Disc.bot.GCA.DB.toggleDM(dMember.id, false);
            };

            ch = await getChannel("error");
            await ch.send(`<@213250789823610880>, <@268520118869295105>,\n There was an error sending message to __**${wowsMem.name.replace(/_/g, "\\_")}**__.\`\`\`xl\n${JSON.stringify(err.stack, null, 4) }\`\`\``);
            console.error(err);
        });
    }else{
        // member is not verified on discord, or does not have a connected discord account.
        console.log(`No discord user found for user: ${wowsMem.name}`);
    };
};



Disc.RemoveClan = async function(member){
    console.log("RemoveClan()")
    let res;

    let stats = member.displayName.split(" ");
    if(stats.length == 2) stats.unshift("[G-C-A]")
    try{
        await member.setNickname(
            stats.pop(),
            `User left the ${stats.shift()} clan.`
        );
        res = true;
    }catch(err){
        res = err;
    };

    return res;
};


Disc.RemovePerms = async function(member, role){
    let ROLE;
    let res;

    if(!role){ //Remove all rank roles.
        ROLE = [
            '1126377465741324435', // Private
            '1126377465741324436', // Recruiting Officer
        ];

    }else{ // Remove a specific role.
        let hasRole = false;
        if(!isNaN(role)){ //Number, check for Role ID.
            if(Role_IDs[role]) ROLE = role;
        }else{ // String, check for Role Name.
            for(let ID in Role_IDs){
                let name = Role_IDs[ID];
                if(name === role){
                    ROLE = role;
                    break;
                };
            };
        };
        if(!ROLE) res = `${role} is not a valid Role ID or Role Name.....\n Check Constants.`;
    };


    try{
        await member.roles.remove(
            ROLE,
            "Member has left, or been removed, from the clan!"
        );
        res = true;
    }catch(err){
        res = err;
    };
    return res;
};

Disc.AddPerms = async function(member, role){
    let ROLE;
    let res;

    let hasRole = false;
    if (!isNaN(role)) { //Number, check for Role ID.
        if (Role_IDs[role]) ROLE = role;
    } else { // String, check for Role Name.
        for (let ID in Role_IDs) {
            let name = Role_IDs[ID];
            if (name === role) {
                ROLE = role;
                break;
            };
        };
    };
    if (!ROLE) res = `${role} is not a valid Role ID or Role Name.....\n Check Constants.`;

    try {
        await member.roles.add(
            ROLE,
            "Member has left, or been removed, from the clan!"
        );
        res = true;
    } catch (err) {
        res = err;
    };
    return res;
};

Disc.getLoAs = async function(query){
    let list = [];
    let Members = await Disc.bot.GCA.DB._Get("Members", {active:true});

    for (let x = 0; x < Members.length; x++) {
        let mem = Members[x];
        if (mem.loa){
            if(!query) list.push(mem);
            else list.push(mem[query]);
        };
    };

    return list;
};


Disc.postLoATopic = async function(){
    let LoAs = await Disc.getLoAs();
    LoAs.sort((a, b) => {
        return (Ranks[b.clan_role] - Ranks[a.clan_role])
            || b.name.toLowerCase().localeCompare(a.name.toLowerCase())
    });

    let lists = {loa:[], exempt:[]};

    for (x = 0; x < LoAs.length; x++){
        let mem = LoAs[x];
        if (!mem.loa.loaExempt) lists.loa.push(mem.name/* + `(${Ranks[mem.clan_role]})`*/); else lists.exempt.push(mem.name/* + `(${Ranks[mem.clan_role]})`*/);
    };

    let loaTopic = Disc.bot.GCA.Constants.Messages.loa_topic;
    loaTopic = loaTopic.replace('{#}', lists.loa.length).replace('{NAMES}', lists.loa.join("\n• "));
    if (lists.exempt.length > 0){
        loaTopic = loaTopic.replace('{LOAE}', `\n\nLoA-Exempt List (${lists.exempt.length}):\n• ${lists.exempt.join("\n• ")}`);
    } else loaTopic = loaTopic.replace('{LOAE}', '');

    let loas = await Disc.bot.channels.fetch(Channels.LoA);
    let POST = "";
    if (loas.topic !== loaTopic) {

        console.log("Attempting to update LoAs topic....")
        loas.setTopic(loaTopic, "LoA Update!")
            .then(() => {
                //loas.send("Updated LoA list!\n> See Channel Topic!");
                POST = true;
                console.log("Updated LoAs topic!");
            })
            .catch(err => {
                loas.send("Error updating LoA list in the topic!!");
                POST = false;
                console.log("Error updating LoAs topic!");
            });
    };
    return POST;
};
