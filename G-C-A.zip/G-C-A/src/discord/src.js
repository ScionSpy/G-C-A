const discord = require('discord.js');
let config = require('../config.json');
let DB = config.DataBase;
config = config.xxShadow;

//const DatabaseHandler = require('./Handlers/Database.js');
const DatabaseHandler = require('./Classes/Shadow.js');
const Constants = require('./Handlers/_Constants.js');
const Commands = require('./Handlers/Commands.js');
const Events = require('./Handlers/Events.js');

class ShadowBeta {
    constructor() {
        DB.Beta = true;
        console.log(`\n============\nLoading Client\n============\n`);

        this.bot = new discord.Client({
            presence: {
                status: 'dnd',
                activity: {
                    type: "LISTENING",
                    name: `a Shadow Reboot..`,
                }
            },
            fetchAllMembers: true, //true
            disableMentions: "everyone"
        });
        this.bot.config = config;

        this.bot.db = new DatabaseHandler(DB);
        //this.bot.cache = new CacheHandler(this.bot.db, Debug);
        this.bot.commands = new Commands();
        //this.bot.Rift = new Rift(this.bot);
        this.bot.x = new Constants(this.bot);
    };

    async login() {
        if (!config._token) throw new Error(`Token Required to login!`);
        await this.bot.login(config._token);
        delete this.bot.config._token;

        this.events = new Events(this.bot)

        this.bot.on("info", (data) => {
            console.log(data);
        });

        //this.bot.on("debug", (d) => { console.log(d) })

        return this;
    };
};
let Client = new ShadowBeta().login();
module.exports = Client;
