const GCA = {
    prefix:"/",
    GCA_Booting: true
};

const https = require('https');
const Web = require('./Web/index.js');
const Discord = require('discord.js');

GCA.DB = require('./Database/index.js');
GCA.Web = require('./Web/index.js');
//GCA.console = GCA.Web.Hooks.console;
GCA.Disc = require('./discord/index.js');
GCA.Constants = require('./Constants.js');

const durations = {
    membersTimer:1800000,
    inactiveTimer:86400000,
    //inactiveTimer: 21600000,


    "6hours":21600000,
    "30min":1800000,
    "1hour":3600000,
    "1day":86400000,

    "midnight": async function(d = new Date()){
        let ms = new Date(d).setHours(24,0,0,0) -d;
        return ms;
    },

    "navalBattles": async function(){
        var dayOfWeek = 5;//friday
        var date = new Date();
        date = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        date.setDate(date.getDate() + (dayOfWeek + 7 - date.getDay()) % 7);


        nextNavalBattle = date.getTime();
        nextNavalBattle = nextNavalBattle - Date.now();

        if(nextNavalBattle < 0) {
            nextNavalBattle = (nextNavalBattle +604800000);
        };

        // Navalbattles start at 1:10AM EST, `nextNavalBattle` is set to refernce 'Monday - Midnight', so we still need to add an hour and 10 minutes.
        return nextNavalBattle +4200000;
    },

    "clanBattles": async function (date = new Date()) {
        let startDate = new Date(GCA.Constants.ClanBattles.start);
        let endDate = new Date(GCA.Constants.ClanBattles.end);
        if (!startDate || isNaN(startDate.getTime())) startDate = 0; //Prevent an issue with "end" not being set, or set incorrectly resulting in 'new Date()' producing an error.
        if(!endDate || isNaN(endDate.getTime())) endDate = 0; //Prevent an issue with "end" not being set, or set incorrectly resulting in 'new Date()' producing an error.
        //if(Date.now() < startDate.getTime()) return null;
        if(Date.now() > endDate.getTime()) return null;


        let Today = new Date();
        Today = new Date(date.getFullYear(), date.getMonth(), date.getDate());

        let day = Today.getDay();

        let nextClanBattle = await durations.midnight();
        let startDateMs = (startDate.getTime() - Date.now())
        if (startDateMs > nextClanBattle) nextClanBattle = startDateMs;
        if (nextClanBattle > 2147483647) return null;
        switch (day) {
            case (1): nextClanBattle = nextClanBattle + (durations['1day'] * 2); break;
            case (2): nextClanBattle = nextClanBattle + (durations['1day'] * 1); break;
            case (5): nextClanBattle = nextClanBattle + (durations['1day']); break;
            //default: nextClanBattle = await durations.midnight()
        };

        //nextClanBattle = nextClanBattle;

        // ClanBattles last entry is 11:30PM EST, 'nextClanBattle' is set to refernce 'Midnight' of clan battle day.
        // WoWs battles can last a maximum of 20 minutes, stating the last possible second being 11:50PM EST,
        // so we need to subtract 10 minutes from our clock.
        if (nextClanBattle < 600000) {
            switch (day) {
                case (0): nextClanBattle = nextClanBattle + await durations['1day'] * 3;    break;//Sunday
                case (3): nextClanBattle = nextClanBattle + await durations['1day'];        break;//Wednesday
                case (4): nextClanBattle = nextClanBattle + await durations['1day'] * 2;    break;//Thursday
                case (6): nextClanBattle = nextClanBattle + await durations['1day'];        break;//Saturday
                //default: nextClanBattle = await durations.midnight()
            };

        };

        return nextClanBattle - 600000;
    },
};


let Embeds = [];
GCA.console = async function message(content, holdPost = false) {
    console.log(content
        .replace('```xl', '')
        .replace('```', '')
        , ">>> GCA_CONSOLE <<<"
    );


    Embeds.push({
        description: content,
        //timestamp: true
    })

    if(holdPost) return Embeds;
    let promise = await new Promise(r => {
        let d = JSON.stringify({
            embeds: Embeds
        });
        let req = https.request(GCA.Constants.Webhooks['gcaConsole'], {
            headers: {
                "Content-type": "application/json",
                "Content-length": Buffer.byteLength(d)
            },
            method: "POST"
        }, r);
        req.write(d);
    });

    Embeds = [];
    return promise;
};

GCA.getTimes = async function(){
    function msToHMS(ms) {
        let h = ms / 3.6e6 | 0;
        let m = (ms % 3.6e6) / 6e4 | 0;
        let s = (ms % 6e4) / 1e3 | 0;
        let ss = (ms % 1e3);
        return `${h}:${('' + m).padStart(2, '0')}:${('' + s).padStart(2, '0')}.${('' + ss).padStart(3, '0')}`;
    };

    function timeToLocalMidnight(d = new Date()) {
        return msToHMS(new Date(d).setHours(24, 0, 0, 0) - d);
    };


};


GCA.Disc.Console = GCA.console;

GCA.Init = async function(options = {}){
    if(options.prefix) this.prefix = options.prefix;
    if(options.bot) this.bot = options.bot

    let members = await GCA.Boot();
    await GCA.Disc.Init(this.bot);


    this.bot.GCA = {};
    this.bot.GCA.DB = GCA.DB;
    this.bot.GCA.Web = GCA.Web;
    this.bot.GCA.Disc = GCA.Disc;
    this.bot.GCA.Constants = GCA.Constants;

    await GCA.StartTimers(members);  // set to 1 hour.
};

let lastPost = 0;
GCA.NavalBattles = async function(test){

    if ((Date.now() - lastPost) < 604800000) return await GCA.Disc.bot.channels.cache.get(GCA.Constants.Channels.error).send(`Naval Battles attempting to send before 7 days have elapsed!`);
    let msg = `**ATTENTION** <@&1126377465741324435>,\n  **Naval Battles** start today!! Make sure you **[Enable]** them!!`;
    if (test) msg = `\`\`\`diff\n- TEST POST\`\`\`\n**ATTENTION** {{ROLE:MEMBERS}},\n  **Naval Battles** start today!! Make sure you **[Enable]** them!!`;

    let clanInfo = await GCA.Disc.bot.channels.cache.get(GCA.Constants.Channels.clanInfo);
    if(test) clanInfo = await GCA.Disc.bot.channels.cache.get(GCA.Constants.Channels.error);

    lastPost = Date.now();
    return await clanInfo.send(msg);
};

GCA.ClanBattles = async function(){
    const Levels = {
        1: 'I',
        2: 'II',
        3: 'III',
        4: 'IV',
        5: 'V',
        6: 'VI',
        7: 'VII',
        8: 'VIII',
        9: 'IX',
        10: 'X',
        11: '★', //★ // ☆
    };

    const ShipClass = {
        'AirCarrier': 'AC',
        'Battleship': 'BB',
        'Cruiser': 'CC',
        'Destroyer': 'DD',
        'Submarine': ''
    };

    const Leagues = {
        0: "Hurrican",
        1: "Typhoon",
        2: "Storm",
        3: "Gale",
        4: "Squall",
    };


    channel = await GCA.Disc.bot.channels.cache.get(GCA.Constants.Channels.cbResults);

    let battles = await GCA.Web.getClanBattles();

    //battles = JSON.parse(battles);
    //console.log(battles[0]);

    let Team;
    let Ship_IDs = {};
    let Embeds = [];
    let counts = { wins: 0, losses: 0 };


    let Now = Date.now();
    let hrLimit = 1000 * 60 * 60 * 19; //19;        // Previous days battles;
    let battlesSince = new Date();
    battlesSince.setTime(Date.now() - hrLimit);
    console.log(`>> Fetching battles since: ${battlesSince}`);

    for (let x = 0; x < battles.length; x++) {
        let battle = battles[x];


        let battleTime = Date.parse(battle.finished_at);

        if ((Now - battleTime) > hrLimit) {
            lastBattle = (Now - battleTime) / 1000 / 60 / 60 / 24 //default
            break;
        };

        //if(await DB.GetClanBattle(battle.id) != null) break;
        //else await DB.uploadClanBattle(battle);

        let GCA = null;
        let opp = null;


        let players = {
            GCA: [],
            opp: []
        };

        for (let y = 0; y < battle.teams.length; y++) {
            let team = battle.teams[y];

            team.Rankings = `${Leagues[team.league]} ${Levels[team.division]} (${team.division_rating} / 100)`;

            if (team.clan_id === 1000101905) GCA = team;
            else opp = team;

            for (let z = 0; z < team.players.length; z++) {
                let player = team.players[z];
                delete player.ship.icons;
                //delete player.vehicle_id;
                let ShipType;
                if (!Ship_IDs[player.vehicle_id]) {
                    ShipType = await Web.getShipType(player.vehicle_id);
                    Ship_IDs[player.vehicle_id] = ShipType.type;
                };
                ShipType = Ship_IDs[player.vehicle_id];

                let survived;
                player.survived ? survived = '+' : survived = '-';

                let item = `${player.name}\n${survived} ${Levels[player.ship.level]} (${ShipClass[ShipType]}) ${player.ship.name}`;
                if (team.clan_id === 1000101905) players.GCA.push(item);
                else players.opp.push(item);
            };
        };

        let Result = GCA.result != null ? GCA.result : null;
        if (Result === "victory") {
            Result = "Victory!";
            counts.wins++
        } else {
            Result = "Defeat!";
            counts.losses++
        };

        let Delta = GCA.rating_delta;
        if (Delta > 0) Delta = `+${GCA.rating_delta}`;
        Team = GCA.team_number == 1 ? "Alpha" : "Bravo";

        let Ranking = `${Team} Div: ${Leagues[GCA.league]} ${Levels[GCA.division]} (${GCA.division_rating}/100)`;
        let Stage;
        if (GCA.stage !== null) {
            Stage = {};

            if (GCA.stage.type == "demotion") {
                if (GCA.stage.target == "league") Stage.Title = `Struggle to stay in the League.`;
                else Stage.Title = `{Stage_Demotion_Division_TItle.Text}`;

            } else { //We're promoting!!
                if (GCA.stage.target == "league") Stage.Title = `{Stage_Promotion_League_TItle.Text}`;
                else Stage.Title = `{Stage_Promotion_Division_TItle.Text}`;
            };

            Stage.Status = [`[]`, `[]`, `[]`, `[]`, `[]`];

            for (let x = 0; x < GCA.stage.progress.length; x++) {
                let s = GCA.stage.progress[x];
                if (s == "victory") Stage.Status[x] = "★ ";
                else Stage.Status[x] = "✩ ";
            };


        };

        let _Stage = ``;

        let color = GCA.result === "victory" ? "228B22" : "800000";

        const Embed = new Discord.MessageEmbed();
        Embed.setTitle(`${Result} (${Delta}) on ${battle.map.name}\n${Ranking}${_Stage}`);
        //Embed.setAuthor(message.guild.name, message.guild.iconURL());
        Embed.setAuthor("Embed.setAuthor(message.guild.name, message.guild.iconURL());")
        Embed.setColor(color);
        Embed.setTimestamp(battle.finished_at);

        if (Stage) Embed.addField(Stage.Title, `\`\`\`js\n${Stage.Status.join(" ")}\`\`\``);
        Embed.addField(`[${GCA.claninfo.tag}]\n${GCA.claninfo.name}\n• ${GCA.Rankings}`, `\`\`\`diff\n${players.GCA.join("\n\n")}\`\`\``, true);
        Embed.addField(`[${opp.claninfo.tag}]\n${opp.claninfo.name}\n• ${opp.Rankings}`, `\`\`\`diff\n${players.opp.join("\n\n")}\`\`\``, true);

        Embeds.unshift(Embed);
    };

    if (Embeds.lengrh == 0) return channel.send(`No Battles found. (last battle was ${lastBattle} hrs ago...`)
    for (let x = 0; x < Embeds.length; x++) {
        channel.send(Embeds[x]);
    };
    channel.send(`Tonights Stats; ${Team} Div:\`\`\`js\n  Wins : ${counts.wins}\nLosses : ${counts.losses}\`\`\`See: https://clans.worldofwarships.com/clan-battles/history`);

};

GCA.CallToArms = async function(){
    let ch_ReadyLounge = await GCA.Disc.bot.channels.cache.get('1126377466647294017'); //#Ready-Lounge
    let ch_divOne = await GCA.Disc.bot.channels.cache.get('1126377466647294018'); //#divison 1
    let ch_divTwo = await GCA.Disc.bot.channels.cache.get('1126377466647294019'); //#diviion 2

    let ch_clanBattles = await GCA.Disc.bot.channels.cache.get('1126377466647294016'); //#clan-battles-lobby

    if (
        ch_ReadyLounge.members.size == 7 || ch_divOne.members.size == 7 || ch_divTwo.members.size == 7
    ) return await GCA.console(`Fired Event: [CB.CallToArms[1]], however there were already 7 people in the channel!`);

    ch_clanBattles.send(`<@&1126377465741324435>,\n> Clan Battles start in 30 Minutes!`);

    //TODO: Make another call requesting {x} members at 7:30
};

GCA.startNavalBattleTimer = async function(){
    console.log(`Starting NavalBattles timer.`);

    let navalBattlesTimer = await durations["navalBattles"]()
    await GCA.console(`Naval Battles timer firing in DD days HH hours MM minutes SS seconds.`
        .replace('DD', Math.floor(navalBattlesTimer / 1000 / 60 / 60 / 24))
        .replace('HH', Math.floor(navalBattlesTimer / 1000 / 60 / 60) % 24)
        .replace('MM', Math.floor(navalBattlesTimer / 1000 / 60) % 60)
        .replace('SS', Math.floor(navalBattlesTimer / 1000 ) % 60)
    , true);

    setTimeout(async function () { //Get time until next Naval Battle!
        await GCA.NavalBattles();
        GCA.startNavalBattleTimer();
    }, navalBattlesTimer);
};

GCA.startClanBattlesTimer = async function(){
    console.log(`Starting ClanBattles timer.`);

    let clanBattlesTimer = await durations["clanBattles"]();
    if(clanBattlesTimer !== null){
        await GCA.console(`Clan Battles timer firing in DD days HH hours MM minutes SS seconds.`
            .replace('DD', Math.floor(clanBattlesTimer / 1000 / 60 / 60 / 24))
            .replace('HH', Math.floor(clanBattlesTimer / 1000 / 60 / 60) % 24)
            .replace('MM', Math.floor(clanBattlesTimer / 1000 / 60) % 60)
            .replace('SS', Math.floor(clanBattlesTimer / 1000) % 60)
        );

        //Sets the results timer.
        setTimeout(async function () { //Get time until next Clan Battle!
            await GCA.ClanBattles();
            GCA.startClanBattlesTimer();
        }, clanBattlesTimer);


        // clanBattlesTimer = '11:50
        // callToArms = '7:00'
        let callToArms = clanBattlesTimer - (1000*60*60*4 + 1000*60*50);
        if (callToArms < ((1000 * 60 * 4) + (1000 * 60 * 50))) return;
        await GCA.console(`Clan Battles [Call to Arms] timer firing in DD days HH hours MM minutes SS seconds.`
            .replace('DD', Math.floor(callToArms / 1000 / 60 / 60 / 24))
            .replace('HH', Math.floor(callToArms / 1000 / 60 / 60) % 24)
            .replace('MM', Math.floor(callToArms / 1000 / 60) % 60)
            .replace('SS', Math.floor(callToArms / 1000) % 60)
        );

        //Sets the "Call to Arms" timer.
        setTimeout(async function () {
            await GCA.CallToArms();
        }, callToArms);
    }else{
        GCA.console(`ClanBattles timer == null [CB Season has ended, or the new season is longer than 25 days away!]`);
    };
};

GCA.forignMemberUpdates = async function(){

};

GCA.StartTimers = async function(members){

    await GCA.console(`Member timer duration set for ${durations["membersTimer"] / 1000 / 60 / 60} hour(s)`, true);
    await GCA.console(`Activity timer duration set for ${durations["inactiveTimer"] / 1000 / 60 / 60 / 24} day(s)`, true);

    //Execute Discord
    await GCA.Disc.postInactives(members.members);
    await GCA.Disc.postUpdates(members.syncedMembers);
    setTimeout(async function () { GCA.console(`Starting Non-GCA Updater!`);
        await GCA.Disc.updateVerified(); }, 1000 *60 *5); //Time for first Non-GCA Clan/Rank Update. // 5 minutes after start-up.
    let Times = await GCA.getTimes();
    //await GCA.NavalBattles();

    setInterval(async function () { // Members check.
        //Execute Discord
        let boot = await GCA.Boot();
        await GCA.Disc.postUpdates(boot.syncedMembers);
    }, durations["membersTimer"]);


    setInterval(async function(){ // Activity check.
        //Execute Discord
        let boot = await GCA.Boot();
        await GCA.Disc.postInactives(boot.members);
        await GCA.Disc.updateVerified();
    }, durations["inactiveTimer"]);


    await GCA.startNavalBattleTimer();
    await GCA.startClanBattlesTimer();
    //Add Verified member check every 24hrs.
    // // Cross ref DB.verified name with Wows DB.name, verify in-game clan by discord clan tag.
};

let Count = 1;
GCA.Boot = async function(){
    delete GCA.GCA_Booting;
    console.log(`GCA Start Complete.`);

//    let nextCheck = await GCA.DB.getNextCheck();
//    if(Date.now() > nextCheck){

    let WebData = await GCA.Web.Start();
    let syncedMembers = await GCA.DB.syncMembers(WebData.Members);
    //syncedMembers.updated = [{name:cMember.name, newRole:member.role, oldRole:cMember.role, wasPromoted<bool>}]
    let members = await GCA.DB.getInactives();

//        nextCheck = await GCA.DB.updateLastCheck();

//        setTimeout(GCA.Boot, nextCheck);
//        console.log(`Setting new timeout for ${nextCheck}`)

    if (syncedMembers.new[0] || syncedMembers.returning[0] || syncedMembers.updated[0] || syncedMembers.removed[0]){
        await GCA.console(`Member Status Count #${Count++}: \`\`\`xl\n${JSON.stringify(syncedMembers, null, 4)}\`\`\``);
    };
    return {syncedMembers, members};
//    }else{
//        console.log(`Set timeout for an old timer...`);
//        setTimeout(GCA.Boot, nextCheck);
//    };
};


GCA.announce = async function(members){

};

module.exports = GCA;
GCA.Disc.GCA = GCA;
