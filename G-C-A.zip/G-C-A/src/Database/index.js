const Web = require('../Web/Requests.js');
const lookup = Web.playerLookup;

const DB_Creds = require('../../config.json').database;
const _DB = require('./core.js');
const DB = new _DB(DB_Creds);
const db = {};
module.exports = db;

const _Constants = require('../Constants.js');

//#region Core Functions.
db._Get = async function(table, data, proj, opt){
    let res = await DB._Get(table, data, proj, opt);
    return res;
};

db._Post = async function (table, data) {
    let res = await DB._Post(table, data);
    return res;
};

db._Edit = async function (table, query, newData) {
    let res = await DB._Edit(table, query, newData);
    return res;
};

db._Delete = async function (table, data) {
    let res = await DB._Delete(table, data);
    return res;
};
//#endregion

db.isRecruiter = async function(memberName){
    let isRec = false;
    let member = await this.getMember(memberName);
    if(!member) return null;
    if (_Constants.Ranks[member.clan_role] > _Constants.Ranks["commisioned_officer"]){
        isRec = true;
    };
    return isRec;
};

db.isHigherThan = async function(wantedRank){

};




db.getNextCheck = async function(){
    let check = await DB._Get("Config", {nextCheck:1});
    return check[0];
};

db.updateLastChecked = async function(){
    let NOW = Date.now();
    let res = await DB._Edit("Config", {
        lastCheck: NOW,
        nextCheck: NOW +(1000*60*60),
    });
    return NOW + (1000*60*60);
};

/**
 *
 * @param {boolean} active
 * @returns
 */
db.getMembers = async function(active){

    let Data;

    if(active) Data = await DB._Get("Members", { active: true });
    else Data = await DB._Get("Members");

    return Data;
};

db.getMember = async function(member){

    if (typeof member == "number" || !isNaN(member)) query = { id: member };
    else if (typeof member == "string" && isNaN(member)) query = { name: member };

    Data = await DB._Get("Members", query);
    Data = Data[0];

    return Data;
};

/**
 *
 * @param {object} member {
        account_id: int,
        account_name: str,
        role: str,
        joined_at: int
    }
 * @returns boolean
 */
db.addMember = async function(member){
    if(!member || typeof member !== "object") return new Error(`'member' must be defined, and an object, got ${typeof member}`);

    if (!member['account_id'] || typeof member['account_id'] !== "number") return new Error('member must have an account_id field, value int');
    if (!member['account_name'] || typeof member['account_name'] !== "string")  return new Error('member must have an account_name field, value str');

    let Data = {
        active: true,
        id: member['account_id'],
        name: member['account_name'],
        clan_role: member['role'],
        clan_joined: member['joined_at']
    };

    let results = await DB._Post("Members", Data);
    if(results.acknowledged) return results.acknowledged;
    else return results;
};

db.toggleMember = async function(memberID, force = undefined, role = "private"){
    if(!memberID) return new Error(`'memberID must be defined to toggle them!`);
    let status;

    if(force === undefined){
        let member = await db.getMember(memberID);
        status = !member.active;
    }else{
        status = force;
    };

    if (status == false) role = null;

    let result = await DB._Edit("Members", {id:memberID}, {"active":status, "clan_role":role});

    return result;
};

db.updateMember = async function (memberID, updates) {
    if (!memberID) return new Error(`'memberID must be defined to edit them!`);

    let member = await db.getMember(memberID);

    for (let key in updates) {
        member[key] = updates[key];
    };

    let results = await DB._Edit("Members", {id:memberID}, member);
    return results;
};

db.setLoA = async function (memberID, auther, reason, loaExempt) {
    if (!memberID) return new Error(`'memberID must be defined to edit them!`);
    let res;

    if(reason == "null" || reason == "clear"){
        res = await DB._Edit("Members", { id: memberID }, { "loa": null });

    } else {
        let loa = {
            auth: auther,
            start: Date.now(),
            loaExempt: loaExempt,
            reason
        };

        res = await DB._Edit("Members", { id: memberID }, { "loa": loa });

    };
    if (res.modifiedCount > 0) res = true;
    else res = false;
    return res;
};


//If a member is currently in the clan that "Wasn't" in the clan, add them to the list, and inform discord of the addition.
// // If a member has "left" the clan, inform discord trhe member has left the clan, if a user on discord has assigned their account, or has a similar username/nickname as the user, remove their roles.
// // // Asign "Clan Firneds"????


/**
 *
 * @param {*} members
 * @returns object
 * {
 *
 * new: Array[ Objects ],
 *
 * returning: Array[ Objects ],
 *
 * updated: Array[ Objects ],
 *
 * removed: Array[ Objects ],
 *
 * }
 */
db.syncMembers = async function(members){
    /*
    members = [
        {
            role: <String>, // {Ranks} above.
            joined_at: int, Date.now() /1000
            account_id: int,
            account_name: Str,
            lastBattle: int // Date.now() /1000
        }
    ]
    */
    console.log(`\nSyncing Members.`);

    let currentMembers = await db.getMembers() || [];
    let update = {
        new:[],
        returning:[],
        updated:[],
        removed:[],
    };

    //Check our currentMembers, do we need to deactivate or update anyone??
    for(x=0;x<currentMembers.length;x++){
        let cMember = currentMembers[x]; // Database
        let member = members[cMember.id] || null; //WoWs

        if(!member){ // If they're not in GCA
            if(cMember.active){ // But the DB says they are.
                await db.toggleMember(cMember.id, false);
                await db.setLoA(cMember.id, null, "null")
                let r = await DB._Get("Verified", {name:cMember.name});
                cMember.discord_id = r[0].discord_id;
                update.removed.push(cMember);
            };

            // Delete from inactives;

            await DB._Delete("Inactives", { name: cMember.name });

        }else{
            //console.log(member, cMember);
            if(member.role !== cMember.clan_role){
                //Members role has changed in the clan!
                let wasPromoted;

                if (_Constants.Ranks[member.role] > _Constants.Ranks[cMember.clan_role]) wasPromoted = true;
                else wasPromoted = false;

                await db.updateMember(cMember.id, {clan_role:member.role});

                update.updated.push({name:cMember.name, newRole:member.role, oldRole:cMember.clan_role, wasPromoted});
            };
            if(member.lastBattle !== cMember.last_battle){
                await db.updateMember(cMember.id, { last_battle: member.lastBattle });
            };
        };
    };

    //Check the currentMembers, do we need to add anyone?
    for(let key in members){
        let member = await db.getMember(members[key].account_id); //Is the new member in our list?
        if(!member){ //No they're not.
            await db.addMember(members[key]);
            update.new.push(members[key]);

        }else if(!member.active){ //They are, but inactive,
            await db.toggleMember(member.id, true, members[key].role);
            update.returning.push(members[key]);
        };
    };

    return update;
};

db.postInactives = async function(inactives){

    for(let x = 0; x<inactives.length;x++){
        let member = inactives[x];
        await DB._Post("Inactives", member);
    };

    return true;
};

db.getOldInactives = async function(){
    let res = await DB._Get("Inactives");
    return res;
};

db.getInactives = async function(){
    console.log("\nGetting Inactives")
    let members = await this.getMembers(true);
    let oldInactives = await this.getOldInactives() || [];
    if(oldInactives === false){
        oldInactives = [];
        console.log("Fired failsafe 'oldInacitves = []' metohd!!");
    };

    let inactive = [
        // { rank:str, name:str, lastBattle:int }
    ];
    let newInactives = [];

    let nowActive = [];

    for(const Member in members){
        let member = members[Member];
        let lastBattle = (Date.now() /1000) - member.last_battle;
        let _lastBattle = lastBattle /60/60 /24

        if(lastBattle > _Constants.Inactive ){
            let isOld = false;
            let wasMsgd = false;

            for(let x = 0; x<oldInactives.length;x++){
                let m = oldInactives[x];

                if(member.name === m.name){
                    isOld = true;
                    wasMsgd = m.adminMsg;
                };
            };

            inactive.push({
                isOld:isOld,
                loa:member.loa,
                rank:member.clan_role,
                joined:member.clan_joined,
                name:member.name,
                _lastBattle,
                discord_id: member.discord_id,
                dmLocked: member.dmLocked,
                adminMsg:wasMsgd
            });

            if(!isOld){
                newInactives.push({
                    noticeCount:0,
                    name:member.name,
                    _lastBattle,
                    dmLocked: member.dmLocked
                });
            };
        }else{ //the member is active.
            for(let x = 0; x<oldInactives.length; x++){
                let cMem = oldInactives[x];

                if(member.name === cMem.name){
                    //member.client.Disc.Console(`Deleting ${member.name} from the inactives list.`);
                    console.log(`Deleting ${member.name} from the inactives list.`);
                    nowActive.push(member.name);
                    DB._Delete("Inactives", {name:member.name});
                };
            };
        };
    };

    await this.postInactives(newInactives);

    //Sort inactives by length, then name.
    inactive.sort((a, b) => (b._lastBattle > a._lastBattle) ? 1 : (b._lastBattle === a._lastBattle) ? ((b.name > a.name) ? 1 : -1) : -1);

    return { inactive, nowActive };
};


db.bindMember = async function(name, discID, notClan){
    if(!name || typeof name !== "string") throw new Error(`{name} must be a string! Got ${typeof name}: ${name}`);
    if(!discID || isNaN(discID)) throw new Error(`{discID} must be a number! Got ${typeof discID}: ${discID}`);
    let res;


    if (notClan) {
        let list = await lookup(name) || [];
        if (list['status'] == "error") throw new Error(JSON.stringify(list, null, 4));

        if (!list || list.length == 0){
            res = `There is no member on the NA WoWs server with a name starting with "**${name}**".\n  Please verify the spelling..`;

        }else{
            res = await DB._Edit("Verified", { id: notClan }, { id: notClan, name: name, discord_id: discID });
            res = res.acknowledged;

        };

        return res;
    };

    let member = await this.getMember(name);
    if (!member || member.length == 0){
        let list = await lookup(name) || [];
        if(list['status'] == "error") throw new Error(JSON.stringify(list, null, 4));

        if(!list || list.length == 0){
            res = `There is no member on the NA WoWs server with a name starting with "**${name}**".\n  Please verify the spelling, or check https://clans.worldofwarships.com/clan-profile/1000101905/members for a list of current clan members."`;
        }else{
            let lookedUp = `Otherwise, I found ${list.length > 1 ? "these names" : "this name"} on the WoWs databases: (and end your command with an \` x\`!!)\n \`${list.join(`\`, \``)}\``;
            if(list[0] == name) lookedUp = "";
            res = `There is no member within G-C-A with the name ${name}.\n  Please verify the spelling or check https://clans.worldofwarships.com/clan-profile/1000101905/members for a list of current clan members.\n\n${lookedUp}`;
        };
    }else{
        res = await this.updateMember(member.id, { discord_id: discID });
        res = res.acknowledged;
    };
    return res;
};

db.unbindMember = async function (name, notClan) {
    if (!name || typeof name !== "string") throw new Error(`{name} must be a string! Got ${typeof name}: ${name}`);
    let res;

    if(notClan){
        res = await DB._Edit("Verified", { id: notClan }, { id: notClan, name: name, discord_id: null });

        return res.acknowledged;
    };
    let member = await this.getMember(name);
    if(!member){
        return `There never was a ${name} in the GCA clan.....\n> Remove their roles manually!!`;
    };

    res = await this.updateMember(member.id, { discord_id: null });

    return res.acknowledged;
};

db.isVerified = async function(discoID, retData){
    if (!discoID || isNaN(discoID)) throw new Error(`{discoID} must be a number! Got ${typeof discoID}: ${discoID}`);
    let res = await DB._Get("Verified", {discord_id:discoID});

    if(res){
        if(retData) return res[0];
        else return true;
    }
    else return false;
};


db.toggleDM = async function (discordID, unlocked) {
    if (!discordID || isNaN(discordID)) throw new Error(`{discordID} must be a number! Got ${typeof discordID}: ${discordID}`);
    let res;

    let member = await DB._Get("Members", {discord_id:discordID});
    member = member[0];
    if(!member) throw new Error(`There are no members in the clan with that discord ID!`);

    res = await DB._Edit("Members", {id:member.id}, {dmLocked:!unlocked});
    return res;
};


db.getClanBattleID = async function(battleID){

};
