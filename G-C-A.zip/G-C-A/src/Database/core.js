const { query } = require('express');

//const db = require('../../config.json').database;
const mongo = require('mongodb').MongoClient;
let MongoDB_URI = `mongodb://{USERNAME}:{PASSWORD}@localhost:27017/{TABLE}?authSource=admin&readPreference=primary&appname=MongoDB%20Compass&ssl=false`;

//const print = console.log;
const print = function () { };
let Beta = "beta_";

class Database {
    constructor(db){
        MongoDB_URI = MongoDB_URI
            .replace('{USERNAME}', db.username)
            .replace('{PASSWORD}', db.password)
            .replace('{TABLE}', db.table)
    };

    /**
     * Opens a connection to the Database.
     * @returns Database.
     */
    #__Open = async function () {
        if (!MongoDB_URI) throw new Error(`Cannot open Database! URI not set! {config.URI}`);
        let promise = await new Promise(function (res, rej) {
            mongo.connect(MongoDB_URI, { useUnifiedTopology: true }, (err, db) => {
                if (err) {
                    let m = '';
                    if (err == 'MongoServerSelectionError: connect ECONNREFUSED 127.0.0.1:27017') {
                        m = 'Check the service: Control Pannel, System+Security/AdminTools/Services/MongoDB Server = "Start"'
                    };
                    rej(`Error Opening Database instance!\n${err}`);
                };
                res(db);
            });
        });
        if (!promise) throw new Error(promise);
        return promise;
    };
    /**
     * Close connection to the Database.
     * @param {Object} db Parameter representing a Mongo Database.
     * @returns Promise{ <Any> }
     */
    //const __Close = async function(db){ if(db) return await db.close(); };
    _Get = async function (collection, query, proj, opt = { sort: null, limit: null }) {
        if (!collection) throw new Error(`Get() must have a collection<String>!`);
        if (typeof collection !== "string") throw new Error(`Get() 'collection' must be a string!`);
        if (typeof query !== "undefined" && typeof query !== "object") throw new Error(`Get() 'query' must be undefined or an object! Got ${typeof query}!`);

        if (!query) query = {};

        let DB; //So we can close the DB later.
        //#region Projections
        let project = {};
        if (proj) {
            project = proj;
        } else {
            // Projection cannot have a mix of inclusion and exclusion.
            //   So if we have a {proj} we cannot hide these values otherwise we'll get an error.
            //   Besides, if the values are not listed in our projection we wont see them anyway!
            project.lastModified = 0;
            project.createdAt = 0;
        };
        project._id = 0; //_id is the only value you can exclude while including items.
        //#endregion

        let sort = opt.sort || null;
        let limit = opt.limit || null;

        return await this.#__Open()
            .then((db) => {
                DB = db;
                return DB.db().collection(Beta + collection);
            })
            .then((collection) => {
                return collection.find(query).project(project).sort(sort).limit(Number(limit)).toArray();
            })
            .then(async (result) => {
                DB.close();
                print(`[Get] [${collection}]:
         Proj: ${JSON.stringify(project)}
        Query: ${JSON.stringify(query)}
          Res: ${result}`);
                if (result.length == 0) return false;
                else {
                    //if(result.length == 1) result = result[0];
                    return result;
                };
            })
            .catch((err) => {
                console.error(err);
                //DB.close();
                return err;
            });
    };
    _Post = async function (collection, data) {
        if (!collection || !data) throw new Error(`Post() must have a collection<String> and data<Object>!`);
        if (typeof collection !== "string") throw new Error(`Post() 'collection' must be a string!`);
        if (typeof data !== "object") throw new Error(`Post() 'data' must be an object!`);

        let DB;
        return await this.#__Open()
            .then((db) => {
                DB = db;
                return DB.db().collection(Beta + collection);
            })
            .then(async (collection) => {
                data.createdAt = Date.now();
                return await collection.insertOne(
                    data
                );
            })
            .then((result) => {
                DB.close();
                print(`[Post] [${collection}]:
        Data: ${JSON.stringify(data)}`);
                return result;
            })
            .catch((err) => {
                //DB.close();
                console.error(err);
                return err;
            });
    };
    _Edit = async function (collection, searchQuery, newData, postResult = true) {
        if (!collection || !searchQuery || !newData) throw new Error(`Edit() must have a collection<String>, query<Object>, and newData<Object>!\n Got: collection<${typeof collection}>, query<${typeof query}>, and newData<${typeof newData}>`);
        if (typeof collection !== "string") throw new Error(`Edit() 'collection' must be a string!`);
        if (typeof searchQuery !== "object") throw new Error(`Edit() searchQuery must be an object!`);
        if (typeof newData !== "object") throw new Error(`Edit() newData must be an object!`);


        let DB; //Used to close the Database later..

        return await this.#__Open()
            .then((db) => {
                DB = db;
                return db.db().collection(Beta + collection);
            })
            .then((collection) => {
                newData.lastModified = Date.now();
                return collection.updateOne(
                    searchQuery,
                    { $set: newData, },
                    { upsert: true } //if the document {searchQuery} returns null/false, then create a new one with the {newData} obeject.
                );
            })
            .then(async (result) => {
                let msg = `[Edit] [${collection}]:
         Query: ${JSON.stringify(searchQuery)}
        Update: ${JSON.stringify(newData)}`;

                if (result.upsertedId) {
                    /*await this._Edit(collection,
                        { _id: result.upsertedId._id },
                        { createdAt: Date.now() }
                    );*/
                    msg = `[Edit] [${collection}] -> Added new entry.`;
                };

                if (postResult) print(msg);
                DB.close();
                return result;
            })
            .catch((err) => {
                console.error(err);
                return err;
            });
    };
    _Delete = async function (collection, query) {
        if (!collection || !query) throw new Error(`Get() must have a collection<String>, and a query<object>!`);
        if (typeof collection !== "string") throw new Error(`Get() 'collection' must be a string!`);
        if (typeof query !== "object") throw new Error(`Get() 'query' must be an object!`);

        let DB;
        return await this.#__Open()
            .then((db) => {
                DB = db;
                return DB.db().collection(Beta + collection);
            })
            .then(async (collection) => {
                return collection.deleteOne(query);
            })
            .then((result) => {
                DB.close();
                print(`[Delete] [${collection}]:
        Data: ${JSON.stringify(query)}`);
                return result;
            })
            .catch((err) => {
                //DB.close();
                console.error(err);
                return err;
            });
    };

};

module.exports = Database;
