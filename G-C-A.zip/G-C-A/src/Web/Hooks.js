const https = require('https');
const Webhooks = require('../Constants.js').Webhooks;

class Hooks {
    Embeds = [];
    construtor(){

    };

    post = async function(hook, data){
        let promise = await new Promise(r => {
            let req = https.request(hook, {
                headers: {
                    "Content-type": "application/json",
                    "Content-length": Buffer.byteLength(data),
                },
                method: "POST"
            }, r);
            req.write(data);
        });
        return promise;
    };

    console = async function(content, holdPost = false) {
        console.log(content
            .replace('```xl', '')
            .replace('```', '')
            .replace('@Shadow', '<@213250789823610880>')
        );


        this.Embeds.push({
            description: content,
            //timestamp: true
        })

        if (holdPost) return this.Embeds;

        let data = JSON.stringify({
            embeds: this.Embeds
        });

        this.Embeds = [];
        return await this.post(Webhooks['gcaConsole'], data);
    };


};


module.exports = Hooks;

/*
Hooks.ClanMemberStatus = async function(username, status){

    let promise = await new Promise(r => {
        let d = JSON.stringify({

        });

        let req = https.request(Webhooks['gcaConsole'], {
            headers: {
                "Content-type": "application/json",
                "Content-length": Buffer.byteLength(d)
            },
            method: "POST"
        });

        req.write(d);
    });

    Embeds = [];
    return promise;
};

*/
