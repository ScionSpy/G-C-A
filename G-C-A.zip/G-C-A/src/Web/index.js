const Web = require('./Requests');
module.exports = Web;

//const Hooks = require('./Hooks.js');
//Web.Hooks = new Hooks();



Web.Start = async function(){
    console.log(`Starting WebFetcher.`);
    let { members, member_ids } = await Web.getClanMembers(true);
    currentMembers = await _AddLastBattle(members, member_ids);

    return {
        Members: currentMembers
    };
};


const _AddLastBattle = async function(members, IDs){

    let playerStats = await Web.getPlayerStats(IDs);
    for (const memberID in playerStats){
        members[memberID].lastBattle = playerStats[memberID].last_battle_time;
    };
    return members;
};
