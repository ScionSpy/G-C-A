const Hooks = require('./Hooks.js');
const https = require('https');
const url = {
    path:'https://api.worldofwarships.com/wows/',
    app_id:'application_id=eec4c249227db89c659d027b9b7b4d36&',
    clan_id:'1000101905'

};

const makeRequest = async function(method, query){
    if(method.startsWith('/')) method.replace('/','');
    if(!method.endsWith('/')) method = method + '/';


    let URL = url.path + method + '?' + url.app_id + query;
    let Data;
    let promise = new Promise(function(res, rej){
        const request = https.request(URL, (response) => {
            let data = '';
            response.on('data', (chunk) => {
                data = data + chunk.toString();
            });

            response.on('end', () => {
                const body = JSON.parse(data);
                Data = body;
                //Data = data;

                if(Data.status == 'error') rej(Data);
                res(Data);
            });
        })

        request.on('error', (error) => {
            console.log('An error', error);
            rej(error);
        });

        request.end()
    });

    return promise;
};



const handleError = async function(Error){

};




const WebApp = {};
module.exports = WebApp;



// https://api.worldofwarships.com/wows/clans/info/?application_id=eec4c249227db89c659d027b9b7b4d36&extra=members&clan_id=1000101905
WebApp.getClanMembers = async function(){
    let res = await makeRequest('clans/info/', `clan_id=${url.clan_id}&extra=members`);

    /*if(res.status != "ok") return res;
    else {

    };*/

    if (res.status == "ok"){
        let DATA = {
            members: res.data[url.clan_id].members,
            member_ids: res.data[url.clan_id].members_ids
        };
        return DATA;
    }
    else return res;
};


// https://api.worldofwarships.com/wows/account/list/?application_id=eec4c249227db89c659d027b9b7b4d36&search=SEARCH
/**
 *
 * @param {String} name
 * @param {Boolean} all
 * @returns
 */
WebApp.playerLookup = async function depreciated(name, all) {
    if (typeof name !== "string") throw new Error(`Search parameter {name} must be a string. Got ${typeof name}: ${name}`);

    let res = await makeRequest('account/list/', `search=${name}`);

    /*if (res.status == "ok"){
        let list = [];

        for(let x = 0; x<res.data.length;x++){
            if(!all) list.push(res.data[x].nickname);
            else list.push(res.data[x]);
        };

        return list;
    }else return res;*/
    if (res.status == "ok") {

        if (all) return res.data;
        else {
            let list = [];

            for (let x = 0; x < res.data.length; x++) {
                if (!all) list.push(res.data[x].nickname);
                else list.push(res.data[x]);
            };

            return list;
        };
    } else return res;
};



// https://api.worldofwarships.com/wows/account/info/?application_id=eec4c249227db89c659d027b9b7b4d36&account_id=ACCOUNT_ID
WebApp.getPlayerStats = async function depreciated(userID){
    if(typeof userID === "number"){
        let res = await makeRequest('account/info/', `account_id=${userID}`);
        //last_battle_time

        if (res.status == "ok") return res.data[userID].last_battle_time;
        else return res;
    }else{ //it's an array.
        let res = await makeRequest('account/info/', `account_id=${userID.join(",")}`);
        //last_battle_time

        if (res.status == "ok"){
            let data = {};
            for(const id in res.data){
                data[id] = { last_battle_time: res.data[id].last_battle_time };
            };

            return data;
        }
        else return res;
    };
};


// TODO: Re-write, currently supports single ID.
// // Update to support multiple as per API Standard.
WebApp._getPlayerStats = async function getPlayerStats(userID){
    if(typeof userID !== "number") throw new Error('{userID} must be a number!!');

    let res = await makeRequest('account/info/', `account_id=${userID}`);
    if(res.status == "ok") return res.data;
    else return res;
};


// https://api.worldofwarships.com/wows/encyclopedia/ships/?application_id=eec4c249227db89c659d027b9b7b4d36&fields=type&ship_id=4282267344
WebApp.getShipType = async function (shipID) {
    if (typeof shipID !== "number") throw new Error(`Search parameter {shipID} must be a number. Got ${typeof shipID}: ${shipID}`);

    let res = await makeRequest('encyclopedia/ships/', `fields=type&ship_id=${shipID}`);

    if(res.status = "ok"){
        for(const key in res.data){
            return { ship_id:key, type:res.data[key].type };
        };
    }else return res;
};



// ========
// ========

/**
 *
 * @param {string} query name of a single player, or if seperated with commas, exact names of multiple characters.
 * @returns
 */
WebApp.search = async function search(query, exact){
    if (typeof query !== "string") throw new Error(`Search parameter {query} must be a string. Got ${typeof query}: ${query}`);
    //query = query.replace(' ','');
    if(query.length < 3) throw new Error(`Minimum query is 3 characters.`);

    let type = 'startswith';
    if(query.includes(',')) type = 'exact';
    if(type == 'exact' && exact && query.split(','.length > 5)) return `"Cannot collect exact information on more than five (5) users!"`;

    let res = await makeRequest('account/list/', `type=${type}&search=${query}`);
    //if(exact || (res.data && res.data.length == 1)) res = await makeRequest('clans/accountinfo/', 'extra=clan&account_id=' + res.data[0].account_id);

    let Data = [];
    for (uID in res.data){
        let player = res.data[uID];
        let info = await makeRequest('clans/accountinfo/', 'extra=clan&account_id=' + player.account_id);
        Data.push(info[uID])
    };

    if(res.status != "ok"){
        return res;
    }else{
        let data = res.data;
        if(type!='exact' && res.data.length > 5) data = res.data.map(r => r.nickname);

        return data;
    };
};

/**
 *
 * @param {string} query name of a single player, or if seperated with commas, exact names of multiple characters.
 * @returns
 */
WebApp.search = async function search(query, exact){
    if (typeof query !== "string") throw new Error(`Search parameter {query} must be a string. Got ${typeof query}: ${query}`);
    let type = 'startswith';

    //Split the query by comma's.
    // If there are multiple names, this will seperate them.
    let queries = query.split(',');

    //If there are more than 1 name, we have to run an 'exact name search'.
    //  otherwise, we can use a 'startswith' search on a single name - per default.
    if((queries.length > 1) || (exact == true)) type = 'exact';

    //If we're trying to get 'Exact' information on more than 5 names, throw an error.
    //  This is a personal prefernce to prevent longer than wanted delays between API calls.
    if (exact && (queries.length > 5)) return `"Cannot collect exact information on more than five (5) users!"`;

    //Execute for every entry in the array.
    //  This'll still function even if the user is only looking up 1 name.
    for(q in queries){
        //If the name entry is less than 3 characters, throw an error!
        //  WoWs API requires 3 characters for a player name lookup.
        if (queries[q].length < 3) throw new Error(`Minimum query is 3 characters.`);
    };

    //Get the Account ID results.
    let res = await makeRequest('account/list/', `type=${type}&search=${query}`);

    //Either we're looking for exact information already, or there was only a single hit on the name search
    //  Run their name for all info.
    if(type == 'exact' || (res.data && res.data.length == 1)){

        let Data = {};
        for(Player in res.data){
            let player = res.data[Player];

            //Make the API call to get the user's basic data, and their clan if applicable.
            let info = await makeRequest('clans/accountinfo/', 'extra=clan&account_id=' + player.account_id);

            //Make sure the user has had some form of 'Clan Activity' (Minimum of an invite recieved or even them applying)
            if(info.data[player.account_id] != null){

                //Once we have the data, and know it exists, populate it into {Data} by nickname rather than WoW's uID mapping.
                Data[player.nickname] = info.data[player.account_id];
            }else{

                //If they Haven't interacted with any clans, we've got to look them up specifically....
                let lookup = await WebApp._getPlayerStats(player.account_id);
                if(lookup[player.account_id]){
                    let stats = lookup[player.account_id];
                    Data[stats.nickname] = {
                        account_name: stats.nickname,
                        account_id: stats.account_id,
                        //clan: null,
                        //clan_id: null,
                        //role:null,
                        //joined_at:null
                    };
                };
            };
        };

        //Overwrite the orignal data list with the more extensive one.
        res.data = Data;
    }else{

        //If we have more than 5 results on a single name search,
        //  remove all of the "Extra" text and leave our list with JUST the user's name.
        if (type != 'exact' && res.data.length > 5) res.data = res.data.map(r => r.nickname);
    };


    if (res.status != "ok") {
        return res;

    } else {
        return res.data;
    };
};


WebApp.searchClans = async function(query){
    if (typeof query !== "string") throw new Error(`Search parameter {query} must be a string. Got ${typeof query}: ${query}`);


    let info = await makeRequest('clans/list/', `search=${query.split(' ').join('+')}`);
    info = info.data[0];
    return {
        clan_id: info.clan_id,
        name: info.name,
        tag: info.tag,
        created_at: info.created_at
    };
};



//https://api.worldofwarships.com/wows/clans/accountinfo/?application_id=eec4c249227db89c659d027b9b7b4d36&account_id=1029454699&extra=clan
_getPlayerInfo = async function (query) {
    //if (typeof query !== "string") throw new Error(`Search parameter {query} must be a string. Got ${typeof query}: ${query}`);

    let res = await makeRequest('account/info/', 'account_id=' + query);

    if (res.status == "ok") {
        return res.data;
    } else return res;
};


WebApp.getPlayerInfo = async function (player, queryList) {
    if (isNaN(player) && typeof player === "string") {
        let players = await this.playerLookup(player, 1);

        if (players.length == 0) {
            return `No players found with the name of, or starting with ${player}`
        } else if (players[0].nickname.toLowerCase() == player.toLowerCase()) {
            player = players[0].account_id;
        } else if (players.length > 1) {
            return `Multiple results detected! Please redefine your search query!\n\n${players.map(m => m.nickname).join('\n')}`;
        }
    }; //isNaN()

    // "String" accepted, {player} == number, run playerInfo!

    //Execute Web Request function.
    // https://api.worldoftanks.com/wot/account/info/?application_id=eec4c249227db89c659d027b9b7b4d36&account_id=1050276730
    let info = await _getPlayerInfo(player);

    if (info['status'] == 'error') return info;

    let data = {};
    let queryErrors = [];

    for (uID in info) {
        let stats = info[uID];
        data[uID] = {};
        data[uID].account_id = uID;

        for (query in queryList) {
            if (info[uID][query]) {
                data[uID][query] = info[uID][query];
            } else {
                queryErrors.push(query);
            }; // forEach query
        }; //forEach info stat
    }; //forEach info

    return data;
};

//GCA.PI = GCA.Web.getPlayerInfo;









// https://clans.worldofwarships.com/api/ladder/battles/?team=1

WebApp.getClanBattles = async function (query = '1') {

    let URL = 'clans.worldofwarships.com';
    let cookies = [
        //'hllang=en',

        'wsauth_token=RA0OwEaJuWPBK9hmOKZsqyIdjvbDCHxs6uV1OBsXnNyQjMVAm4_9INFCQ2IMjgs1',
        //'wsauth_presence=1',

        //'cm.options.user_id=1043485149',
        //'cm.options.user_name=ShadowSpyy',
        //'cm.internal.spa_id=1043485149',
        //'cm.internal.realm=us',
        //'cm.internal.bs_id=da8a21c4-3011-4514-675a-57ec89a58cf4',

        //'_gcl_au=1.1.218231056.1696961361',
        //'wot_wgnet_lvl=GA1.2.1289880705.1696961361',

        //'_ga_BWRKLL4HR5=GS1.1.1697209365.1.0.1697209365.60.0.0',
        //'_uetvid=50ed9a9069e411eea7dcd730353f9829',
        //'_ga=GA1.2.1289880705.1696961361',
        //'_clck=12v6ykq|2|fft|0|1381'

        //'OptanonAlertBoxClosed=2023-10-13T15:02:20.907Z',
        //'OptanonConsent=isIABGlobal=false&datestamp=Fri+Oct+13+2023+11%3A02%3A20+GMT-0400+(Eastern+Daylight+Time)&version=6.19.0&hosts=&consentId=8797f31b-3592-4a49-b36d-0fd0011a0013&interactionCount=0&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0002%3A1&AwaitingReconsent=false&geolocation=US%3BFL',
    ];

    let data = JSON.stringify(query);

    let Headers = {
        'User-Agent': 'GCA-Applications',
        'Accept': '*/*',
        'Accept-Encoding': 'json',
        'Cookie': cookies.join('; '),
    };

    let options = {
        method: 'GET',
        hostname: URL,
        path: `/api/ladder/battles/?team=${query}`,
        headers: Headers
    };


    let Data;
    let promise = await new Promise(function (res, rej) {
        const request = https.request(options, (response) => {

            let data = '';
            response.on('data', (chunk) => {
                data = data + chunk.toString();
            });


            response.on('end', () => {
                if(data == 'Forbidden') return rej(data);
                const body = JSON.parse(data);
                Data = body;

                res(Data);
            });
        });

        request.on('error', (error) => {
            console.log('An error', error);
            rej(error);
        });

        request.end()
    });

    if(!promise) Hooks.console(`@Shadow,\nWebApp.getClanBattles\n> ${promise}`)
    return promise;
};
