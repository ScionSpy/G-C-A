const https = require('https');
const fs = require('fs');
const Constants = {
    // Inactive = 604,800  @ 7 days.
    Inactive: 60 * 60 * 24 * 7, // seconds * minutes * hours * [Inactive Period] //WoWs doesn't go to ms, only ss

    Guild_ID: "1126377465741324429", // Gemini's Comerads in Arms ( G-C-A )

    ClanBattles: {
        start: 'February 12 2024',
        end: 'April 8 2024'
    },




    Channels: {
        "DM": "1165169909219721246",        // #direct_messages
        "LoA": "1126377466399826036",       // #leave-of-absence
        "cbResults": "1152409627795922944", // #cb_results
        "clanInfo": "1126377466148180057", // #tips-information
        "member_updates": "1136014419567067166", //#member-updates
        "rank_updates": "1136014419567067166", // #member-updates
        "inactives": "1135329167571947534", //#testing-grounds
        "error": "1168784020109266954", //console-spam
    },
    Webhooks: {
        adminLobby: 'https://discord.com/api/webhooks/1222760676104208414/6kdh9BV_XhRYgD5kDwBOy0RmNyhFQ6xpEQetr5Qq63TYHue_UVynO2fkzWH8J_08nDSA',
        gcaConsole: 'https://discord.com/api/webhooks/1168784066494070834/dCRlOqPEC5FdgyqU3UZ-GNWhOSUdNfcwfWEZqycTL-sQpgZYzxPsRe00CY9-8c-w_dOe',
        playerUpdates: 'https://discord.com/api/webhooks/1222752710315479090/0lo2fsBVubmWlGGd2PD9spcYFWLHW5DF70tMN7yO4ERDAxlDOY272bnwX4f7wJexgnP9'
    },


    Ranks: {
        "commander": 5,             // Commander
        "executive_officer": 4,     // Deputy Commander
        "recruitment_officer": 3,   // Recruitment Officer
        "commissioned_officer": 2,  // Commisioned Officer
        "officer": 1,               // Line Officer
        "private": 0,               // Midshipman
        null: -1                    // undefined
    },

    Ranks_Short: {
        "commander": "(CO)",
        "executive_officer": "(XO)",
        "recruitment_officer": "(R)",
        "commissioned_officer": "(C)",
        "officer": "(L)",
        "private": "(M)"
    },

    clans_roles: {
        "commander": "Commander",                       // Build NavalBase, See oil from hidden stat members, edit clan name/tag/desc, edit member's ranks, Kick members.
        "executive_officer": "Deputy Commander",        // Same as CMDR excpet for remove other deputy cmdrs & disband the clan.
        "recruitment_officer": "Recruiter",             // Send/accept invites/applications.
        "commissioned_officer": "Commissioned Officer", // No perms.
        "officer": "Line Officer",                      // No perms.
        "private": "Midshipman",                        // No perms.
        null: "Civilian",                               // Not even a clan mate.....
    },

    Role_IDs: {
        '1126377465741324438': 'commander', // Commander
    //    '': 'executive_officer', // Executive Officer
        '1126377465741324437': '__administrator', // Administrators
    //    '': '', //
        '1126377465741324436': 'recruitment_officer', // Recruiters
        '1126377465741324435': 'private', // Members
        '1126377465741324434': '__mercenary', // Battlers
        '1126377465741324432': '__clan_friends', // Clan Friends
        '1172761177621811220': '__loa_follower', // LoA Follower
    },

    Role_IDs_byName: {
        commander: '1126377465741324438', // Commander
        //    '': 'executive_officer', // Executive Officer
        __administrator: '1126377465741324437', // Administrators
        //    '': '', //
        recruitment_officer: '1126377465741324436', // Recruiters
        private : '1126377465741324435', // Members
        verified: '1137246581205258240', //verified
        __mercenary: '1126377465741324434', // Battlers
        __clan_friends: '1126377465741324432', // Clan Friends
        __loa_follower: '1172761177621811220', // LoA Follower
    },


    Messages: {
        "loa_topic": `[Do NOT modify the topic!]\n[Topic is maintained automatically by GCA's Automaton! ]\n\nList of members with a special circumstance or exemption.\n\nRecruiters can send \"..loa list\" for a detailed list.\n\nLoA List ({#}):\n• {NAMES}{LOAE}`
    },

    Features: {
        "nicknames": `[{TAG}] {RANK} {NAME}`
    },

    Allies : {
        // status {-1: Neutral, 0: Hostile, 1: Ally}
        'RSR': { clan: "Red Star Rising", status: 1, ch: '1184865604050632784', role: '1126377465741324433' },
    },
};



let Embeds = {};
/**
 * Posts a webhook to the determined destination.
 * * If "Hold Post" is selected, can hold up to 10 embeds to send.
 * * * Will wait until 10 is reached, or a post is sent to the webhook without hold designated.
 * @param {String} hook
 * * adminLobby
 * * console
 * * playerUpdates
 * @param {String} content The content to be posted.
 * @param {Boolean} holdPost Should this post wait for the next un-held post, or until 10 have posted?
 * @returns
 */
async function postWebhook(hook, content, holdPost = false) {
    if(!Constants.Webhooks[hook]) throw new Error(`{hook} must be defined! And must be a valid Constants Webhook! Got ${typeof hook} ${hook}`);
    if(!content || typeof content !== "string") throw new Error(`You must provide content to post! And content must be a string! Got ${typeof content} ${content}`);
    console.log(content
        .replace('```xl', '')
        .replace('```', '')
    );

    if(!Embeds[hook]) Embeds[hook] = [];
    console.log("Created Array!", Embeds)

    Embeds[hook].push({
        description: content,
        timestamp: true
    });
    console.log("Created Embed!", Embeds)

    if (holdPost) return Embeds[hook];
    console.log("Posting!")
    let promise = await new Promise(r => {
        let d = JSON.stringify({
            embeds: Embeds[hook]
        });
        let req = https.request(Constants.Webhooks[hook], {
            headers: {
                "Content-type": "application/json",
                "Content-length": Buffer.byteLength(d)
            },
            method: "POST"
        }, r);
        req.write(d);
    });

    console.log("Posted!")
    delete Embeds[hook]; //Reduce memory.
    console.log("Deleted Array!" + hook);
    return promise;
};

const files = [
    "log",
    "warn",
    "error",

    "nicknames", //pertaining to "memberUpdated" discord event.
    "vcUpdate", // pertaining to "vcUpdate" events.
];
/**
 * @param {Object} data data to pass to the logger.
 * * file: file to send data to.
 * * text: text w=to write.
 */
const logToFile = async function(data = {file:'log', text: null}){
    if(!data.text) throw new Error(`{data.text} must be defined to make a log!!`);

    if(!files.includes(data.file)) data.file = "other";

    let timestamp = new Date().toISOString();
    timestamp = timestamp.split('T');
    timestamp[1] = timestamp[1].split('.')[0]; //remove ms.

    timestamp = `[${ timestamp.join(" ") }]: `;

    let p = new Promise(function(res,rej){
        fs.writeFile(`./Logs/${data.file}.txt`, `${timestamp + data.text}\n`, { flag: "a+" }, (err) => {
            if (err) rej(err);
            res(true);
        });
    });

    return p;
};



Constants.logger = logToFile;
Constants.postWebhook = postWebhook;
module.exports = Constants;
